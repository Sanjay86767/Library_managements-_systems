# Athenaeum — MERN Library Management System

Advanced-level library management system built on MongoDB, Express, React and Node.js —
matching the architecture you sketched (client layer → API gateway → service layer → data layer).

## Features

- **JWT authentication** with role-based access (`patron`, `librarian`, `admin`). First registered user auto-becomes admin.
- **Forgot / reset password** — emailed reset link (hashed token, 30-min expiry); falls back to console-logging the link if SMTP isn't configured.
- **Change password** — for logged-in users who know their current password, from an Account tab on both dashboards.
- **Free World Library** — search 70,000+ public-domain books worldwide via Project Gutenberg (Gutendex API) and read them online for free, no login or waiting list required.
- **Wishlist** — save catalog books *and* free worldwide titles to read later.
- **Reviews & star ratings** — patrons rate and review books; the catalog's average rating updates automatically.
- **Advanced search + sort** — full-text search, genre/author filters, and sort by newest, highest-rated, most available, or title.
- **Personalized recommendations** — genre-based suggestions from each patron's own borrowing history.
- **Notifications** — a bell in the navbar surfaces due-soon and overdue alerts, generated automatically from active loans.
- **Book catalog service** — full CRUD, text search across title/author/genre, genre filter, pagination.
- **Borrow/return service** — issue and return flow, live overdue detection, per-patron loan limit (5), duplicate-copy guard.
- **Automatic fine engine** (`utils/fineCalculator.js`) — ₹5/day overdue, capped at ₹500, computed live even before return.
- **Renewals** — up to 2 renewals per loan, blocked while a fine is outstanding.
- **Admin analytics** — totals by genre, copies in circulation vs. on shelf, rendered as a live bar chart (Recharts).
- **Interactive landing page** — animated "bookshelf" hero (hover a spine), live catalog search, real-time stats pulled from the API.
- **Rate limiting, centralized error handling, safe user serialization** (passwords never leave the API).

## Stack

- **Backend:** Node.js, Express, Mongoose, JWT, bcryptjs, nodemailer, axios, express-async-handler, express-rate-limit
- **Frontend:** React 18 (Vite), React Router, Tailwind CSS, Recharts, Axios

## Project structure

```
library-mern/
├── backend/
│   ├── config/db.js
│   ├── models/          User, Book, Transaction, Wishlist, Review, Notification
│   ├── controllers/     auth, book, transaction, user, freeBook, wishlist, review, notification
│   ├── routes/          auth, book, transaction, user, freeBooks, wishlist, review, notification
│   ├── middleware/       authMiddleware (protect, authorize, error handling)
│   ├── utils/            fineCalculator, sendEmail, emailTemplates, gutendexApi
│   ├── seed.js
│   └── server.js
└── frontend/
    └── src/
        ├── pages/        Landing, Login, Register, ForgotPassword, ResetPassword,
        │                 FreeLibrary, BookDetail, PatronDashboard, AdminDashboard
        ├── components/   Navbar, BookCard, ProtectedRoute, StarRating,
        │                 NotificationBell, ChangePasswordForm
        ├── context/AuthContext.jsx
        └── api/axios.js
```

## Setup notes for the new features

- **Free World Library** needs no API key — Gutendex is public and keyless.
- **Password reset emails** need `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` in `backend/.env`; without them the reset link is just printed to the server console (fine for local dev).
- Run `npm install` in `backend/` after pulling — `axios` and `nodemailer` were added as dependencies.


## Run it locally

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env      # then set MONGO_URI and JWT_SECRET
npm run dev                # nodemon, http://localhost:5000
node seed.js                # optional: loads 8 demo books
```

Requires a MongoDB instance — either local (`mongodb://127.0.0.1:27017/athenaeum_library`)
or a free Atlas cluster (paste its connection string into `MONGO_URI`).

### 2. Frontend

```bash
cd frontend
npm install
npm run dev                # http://localhost:5173, proxies /api to :5000
```

### 3. Try it

1. Register — the **first account you create becomes `admin`** automatically.
2. As admin, go to your dashboard → **Inventory** tab → add a few titles (or just run `node seed.js`).
3. Register a second account (a normal patron) and borrow a book from the homepage or dashboard.
4. Back in the admin **Circulation** tab, mark it returned — the fine engine kicks in automatically if it's overdue.

## Advanced features (new)

Everything below works out of the box with **no extra setup** — just `npm install` in both folders:

- **Gamification** — reading points, daily streaks, 7 unlockable badges, and a community leaderboard (patron dashboard → Achievements tab)
- **Admin analytics dashboard** — 6-month issued/returned trend, genre composition pie chart, top borrowers, top-rated titles, fine collection totals (admin dashboard → Analytics tab)
- **Live search-as-you-type** — the catalog search box now searches as you type (debounced), with a subtle fade-in on results
- **Virtual bookshelf view** — toggle "Shelf" next to catalog search for a stylized wooden-shelf browsing view, grouped by genre
- **Community reviews feed** — patron dashboard → Community tab shows the latest reviews from every patron
- **Kanban circulation board** — admin dashboard → Circulation tab is now a drag-and-drop board (Issued / Overdue / Returned); drag a card into "Returned" to check a book in
- **Dark mode** — toggle in the navbar, persisted across sessions
- **Real-time notifications** — Socket.io pushes due-soon/overdue alerts to the bell icon instantly instead of waiting for the next poll
- **Hindi/English toggle** — language switcher in the navbar (हिं / EN), persisted across sessions. Covers the navbar, sign-in/register, and both dashboards' tab labels and core UI strings. It's a lightweight custom `useLanguage()` + `t()` system (no extra dependency) — extend it by adding more keys to `frontend/src/i18n/translations.js` and calling `t("yourKey")`; deep-translating every last string in the app (book descriptions, admin forms, etc.) is a bigger follow-up if you want full coverage.

## Security hardening (new)

All of this works out of the box, no extra API keys needed:

- **Two-factor authentication (TOTP)** — patron/admin dashboard → Account tab → "Enable two-factor authentication" shows a QR code for Google Authenticator/Authy/1Password. Once enabled, login becomes a two-step flow: password, then a 6-digit code. Uses standard TOTP (`otplib`), so it works with any authenticator app — no SMS provider or third-party account needed.
- **Account lockout** — 5 failed login attempts locks the account for 15 minutes (tracked per-user, not per-IP, so a shared office IP doesn't lock out everyone).
- **Stricter rate limiting on auth routes** — `/login`, `/register`, `/forgot-password`, `/reset-password`, and `/2fa/login-verify` are capped at 10 requests / 15 min per IP (separate from and stricter than the app-wide 300/15min limit already in place).
- **Audit log** — every login (success/failure/locked), password change/reset, 2FA enable/disable, book deletion, and fine payment is recorded with actor, IP, user agent, and timestamp. Admin dashboard → **Audit Logs** tab (admin role only — librarians don't see this tab) has a filterable, paginated table.
- **Security headers** — `helmet` is now applied to every response (sensible defaults: no `X-Powered-By`, basic CSP, clickjacking protection, etc.).
- **Correct client IPs behind a proxy** — `app.set("trust proxy", 1)` so rate-limiting and audit logs record the real visitor IP when deployed behind Render/Railway/Nginx/etc., not the proxy's own IP.

Also run `npm install` again in `backend/` — `otplib`, `qrcode`, and `helmet` were added as dependencies.

**Not included (bigger follow-ups if you want them):** IP-based rate limiting in addition to per-account lockout, refresh-token rotation, CAPTCHA on repeated failures, exporting audit logs to CSV, and SMS-based 2FA as a fallback to TOTP.

Two features need your own API keys (the integration code is complete — just fill in `backend/.env`):

- **Online fine payments (Razorpay)** — get test keys from https://dashboard.razorpay.com/app/keys, set `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET`. Without them, the "Pay ₹X online" button on a fine shows a clear "not configured" error instead of failing silently.
- **AI Librarian chat** — get a key from https://console.anthropic.com, set `ANTHROPIC_API_KEY`. The floating chat widget (bottom-right of the patron dashboard) is catalog-aware — it only recommends titles actually in stock. Without a key it tells the patron it isn't configured yet.

Also run `npm install` again in `backend/` — `socket.io` and `razorpay` were added as dependencies — and in `frontend/` — `socket.io-client` was added.

## Extending it further (ideas)

- Cloudinary upload for real book cover images (field already exists: `coverImage`)
- Nodemailer for due-date reminder emails (`Notification Service` in your diagram)
- Reservation/holds queue for books with zero copies available
- CSV export of circulation reports
- Refresh tokens + httpOnly cookie storage instead of localStorage, for production hardening
- A true 3D bookshelf (three.js) — the current shelf view is a lightweight CSS approximation; a real 3D version would be a separate, larger build
