import express from "express";
import { getMyGamification, getLeaderboard } from "../controllers/gamificationController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/mine", protect, getMyGamification);
router.get("/leaderboard", protect, getLeaderboard);

export default router;
