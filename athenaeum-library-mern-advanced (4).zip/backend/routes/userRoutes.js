import express from "express";
import { getUsers, updateUserRole, toggleUserStatus } from "../controllers/userController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, authorize("admin"), getUsers);
router.put("/:id/role", protect, authorize("admin"), updateUserRole);
router.put("/:id/status", protect, authorize("admin"), toggleUserStatus);

export default router;
