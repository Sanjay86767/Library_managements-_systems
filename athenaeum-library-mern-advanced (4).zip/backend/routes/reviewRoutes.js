import express from "express";
import { deleteReview, getReviewFeed } from "../controllers/reviewController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/feed", protect, getReviewFeed);
router.delete("/:id", protect, deleteReview);

export default router;
