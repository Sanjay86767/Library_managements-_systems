import express from "express";
import { createFineOrder, verifyFinePayment } from "../controllers/paymentController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/fine/:transactionId/order", protect, createFineOrder);
router.post("/fine/:transactionId/verify", protect, verifyFinePayment);

export default router;
