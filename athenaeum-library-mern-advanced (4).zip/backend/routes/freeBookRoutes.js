import express from "express";
import { searchFreeBooksHandler, getFreeBookHandler } from "../controllers/freeBookController.js";

const router = express.Router();

router.get("/search", searchFreeBooksHandler);
router.get("/:gutenbergId", getFreeBookHandler);

export default router;
