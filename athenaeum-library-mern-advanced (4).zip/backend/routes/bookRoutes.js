import express from "express";
import {
  getBooks, getBookById, createBook, updateBook, deleteBook, getBookStats, getRecommendations,
} from "../controllers/bookController.js";
import { createReview, getBookReviews } from "../controllers/reviewController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

// Static/named paths must come before "/:id" so Express doesn't treat them
// as a book id.
router.get("/stats/overview", protect, authorize("admin", "librarian"), getBookStats);
router.get("/recommendations/mine", protect, getRecommendations);

router.get("/", getBooks);
router.get("/:id", getBookById);
router.get("/:id/reviews", getBookReviews);
router.post("/:id/reviews", protect, createReview);

router.post("/", protect, authorize("admin", "librarian"), createBook);
router.put("/:id", protect, authorize("admin", "librarian"), updateBook);
router.delete("/:id", protect, authorize("admin", "librarian"), deleteBook);

export default router;
