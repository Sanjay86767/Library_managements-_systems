import express from "express";
import rateLimit from "express-rate-limit";
import {
  registerUser, loginUser, verifyLogin2FA, getMe,
  forgotPassword, resetPassword, changePassword,
  setup2FA, verifySetup2FA, disable2FA,
} from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Tighter limits than the general /api limiter — these are the endpoints
// most worth throttling against credential-stuffing / brute force.
const strictAuthLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { message: "Too many attempts from this device — please wait a few minutes and try again." },
  standardHeaders: true,
  legacyHeaders: false,
});

router.post("/register", strictAuthLimiter, registerUser);
router.post("/login", strictAuthLimiter, loginUser);
router.post("/2fa/login-verify", strictAuthLimiter, verifyLogin2FA);
router.get("/me", protect, getMe);
router.post("/forgot-password", strictAuthLimiter, forgotPassword);
router.put("/reset-password/:token", strictAuthLimiter, resetPassword);
router.put("/change-password", protect, changePassword);

router.post("/2fa/setup", protect, setup2FA);
router.post("/2fa/verify-setup", protect, verifySetup2FA);
router.post("/2fa/disable", protect, disable2FA);

export default router;
