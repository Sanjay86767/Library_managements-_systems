import express from "express";
import {
  issueBook, returnBook, renewBook, getMyTransactions, getAllTransactions,
} from "../controllers/transactionController.js";
import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/issue", protect, issueBook);
router.put("/:id/return", protect, authorize("admin", "librarian"), returnBook);
router.put("/:id/renew", protect, renewBook);
router.get("/mine", protect, getMyTransactions);
router.get("/", protect, authorize("admin", "librarian"), getAllTransactions);

export default router;
