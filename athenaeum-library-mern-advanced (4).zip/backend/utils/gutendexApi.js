import axios from "axios";

// Gutendex is a free, keyless REST API over Project Gutenberg's 70,000+
// public-domain books — no rate-limit headaches, no legal risk, works
// worldwide.
const GUTENDEX_BASE = "https://gutendex.com/books";

const mapGutendexBook = (b) => ({
  gutenbergId: b.id,
  title: b.title,
  authors: (b.authors || []).map((a) => a.name),
  coverUrl: b.formats?.["image/jpeg"] || null,
  languages: b.languages,
  downloadCount: b.download_count,
  subjects: (b.subjects || []).slice(0, 4),
  readOnline: {
    html: b.formats?.["text/html"] || b.formats?.["text/html; charset=utf-8"] || null,
    plainText: b.formats?.["text/plain; charset=utf-8"] || b.formats?.["text/plain"] || null,
    epub: b.formats?.["application/epub+zip"] || null,
  },
});

export const searchFreeBooks = async (query, page = 1) => {
  const { data } = await axios.get(GUTENDEX_BASE, {
    params: { search: query, page },
    timeout: 10000,
  });
  return {
    count: data.count,
    hasNext: Boolean(data.next),
    hasPrevious: Boolean(data.previous),
    page: Number(page),
    results: (data.results || []).map(mapGutendexBook),
  };
};

export const getFreeBookById = async (gutenbergId) => {
  const { data } = await axios.get(`${GUTENDEX_BASE}/${gutenbergId}`, { timeout: 10000 });
  return mapGutendexBook(data);
};
