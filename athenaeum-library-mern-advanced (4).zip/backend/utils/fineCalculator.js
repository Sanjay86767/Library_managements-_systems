// Fine rules for the Athenaeum library
export const FINE_PER_DAY = 5; // currency units per day overdue
export const GRACE_DAYS = 0;
export const MAX_FINE = 500;
export const LOAN_PERIOD_DAYS = 14;
export const MAX_RENEWALS = 2;

export const calculateFine = (dueDate, returnDate = new Date()) => {
  const due = new Date(dueDate);
  const ret = new Date(returnDate);
  const diffMs = ret - due;
  if (diffMs <= 0) return 0;
  const overdueDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24)) - GRACE_DAYS;
  if (overdueDays <= 0) return 0;
  return Math.min(overdueDays * FINE_PER_DAY, MAX_FINE);
};

export const addDays = (date, days) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};
