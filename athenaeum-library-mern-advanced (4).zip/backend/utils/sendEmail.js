import nodemailer from "nodemailer";

const isSMTPConfigured = () =>
  process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS;

let transporter = null;
const getTransporter = () => {
  if (!isSMTPConfigured()) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
  }
  return transporter;
};

// Sends an email if SMTP is configured; otherwise logs it to the console so
// local development still works without any mail setup.
export const sendEmail = async ({ to, subject, html }) => {
  const t = getTransporter();

  if (!t) {
    console.log("\n--- SMTP not configured, email not sent. Preview below ---");
    console.log(`To: ${to}\nSubject: ${subject}\n${html}\n--- end email preview ---\n`);
    return { previewOnly: true };
  }

  return t.sendMail({
    from: process.env.SMTP_FROM || `"Athenaeum Library" <${process.env.SMTP_USER}>`,
    to,
    subject,
    html,
  });
};
