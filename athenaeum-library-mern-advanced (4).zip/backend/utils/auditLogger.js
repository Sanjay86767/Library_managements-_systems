import AuditLog from "../models/AuditLog.js";

// Fire-and-forget audit entry. Security logging should never be able to
// break the actual request it's attached to, so failures here are only
// logged to the server console, never thrown.
export const logAudit = async ({ user, email, action, req, meta = {} }) => {
  try {
    await AuditLog.create({
      user: user || null,
      email: email || null,
      action,
      ip: req?.ip || req?.headers?.["x-forwarded-for"] || null,
      userAgent: req?.headers?.["user-agent"] || null,
      meta,
    });
  } catch (err) {
    console.error("Audit log write failed:", err.message);
  }
};
