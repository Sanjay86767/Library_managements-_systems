// Thin wrapper around the socket.io server instance so controllers can emit
// events without importing server.js directly (would create a require cycle).
let ioInstance = null;

export const setIO = (io) => {
  ioInstance = io;
};

// Every authenticated socket joins a room named after its user id (see
// server.js), so emitting to that room reaches only that patron's open tabs.
export const emitToUser = (userId, event, payload) => {
  if (!ioInstance || !userId) return;
  ioInstance.to(`user:${userId.toString()}`).emit(event, payload);
};
