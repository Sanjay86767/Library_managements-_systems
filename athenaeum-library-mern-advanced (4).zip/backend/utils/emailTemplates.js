export const resetPasswordEmail = (name, resetUrl) => `
  <div style="font-family: Georgia, serif; background:#F3EAD3; padding: 32px; color:#16233D;">
    <div style="max-width:480px; margin:0 auto; background:#ffffff; border:1px solid #B08D57; border-radius:4px; padding:32px;">
      <p style="text-transform:uppercase; letter-spacing:2px; font-size:12px; color:#7A2E2E; margin:0 0 8px;">
        Athenaeum Library
      </p>
      <h2 style="margin:0 0 16px;">Reset your password</h2>
      <p>Hi ${name || "there"},</p>
      <p>We received a request to reset the password on your library account. Click the button below to choose a new one. This link expires in 30 minutes.</p>
      <p style="text-align:center; margin:28px 0;">
        <a href="${resetUrl}"
           style="background:#7A2E2E; color:#ffffff; text-decoration:none; padding:12px 28px; border-radius:2px; font-size:14px; display:inline-block;">
          Reset Password
        </a>
      </p>
      <p style="font-size:13px; color:#555;">If you didn't request this, you can safely ignore this email — your password will stay the same.</p>
      <p style="font-size:12px; color:#888; word-break:break-all;">Or paste this link into your browser: ${resetUrl}</p>
    </div>
  </div>
`;
