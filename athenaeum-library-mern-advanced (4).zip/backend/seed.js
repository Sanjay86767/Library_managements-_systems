// Run: node seed.js   (after setting MONGO_URI in .env)
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import Book from "./models/Book.js";

dotenv.config();
await connectDB();

const books = [
  { title: "The Silent Marker", author: "R. Kavanagh", isbn: "9780001112223", genre: "Mystery", quantity: 3, available: 3, publishedYear: 2018, publisher: "Northbank Press", shelfLocation: "M-12" },
  { title: "Notes on Entropy", author: "S. Iyer", isbn: "9780001112230", genre: "Science", quantity: 2, available: 2, publishedYear: 2021, publisher: "Ridgeline", shelfLocation: "S-04" },
  { title: "A Ledger of Rivers", author: "M. Duarte", isbn: "9780001112247", genre: "Poetry", quantity: 4, available: 4, publishedYear: 2016, publisher: "Willow & Vine", shelfLocation: "P-01" },
  { title: "The Long Winter Court", author: "A. Fenwick", isbn: "9780001112254", genre: "Fiction", quantity: 5, available: 5, publishedYear: 2020, publisher: "Northbank Press", shelfLocation: "F-22" },
  { title: "Empire of Iron Roads", author: "T. Okoye", isbn: "9780001112261", genre: "History", quantity: 2, available: 2, publishedYear: 2019, publisher: "Meridian", shelfLocation: "H-09" },
  { title: "The Grammar of Machines", author: "L. Petrov", isbn: "9780001112278", genre: "Science", quantity: 3, available: 3, publishedYear: 2023, publisher: "Ridgeline", shelfLocation: "S-11" },
  { title: "Salt and Signal", author: "R. Kavanagh", isbn: "9780001112285", genre: "Mystery", quantity: 2, available: 2, publishedYear: 2022, publisher: "Northbank Press", shelfLocation: "M-13" },
  { title: "Letters to a Young Founder", author: "C. Mbeki", isbn: "9780001112292", genre: "Biography", quantity: 3, available: 3, publishedYear: 2017, publisher: "Meridian", shelfLocation: "B-05" },
];

await Book.deleteMany({});
await Book.insertMany(books);
console.log(`Seeded ${books.length} books`);
process.exit(0);
