import asyncHandler from "express-async-handler";
import Transaction from "../models/Transaction.js";
import Book from "../models/Book.js";
import { calculateFine, addDays, LOAN_PERIOD_DAYS, MAX_RENEWALS } from "../utils/fineCalculator.js";
import { recordActivity, awardOnTimeReturn } from "./gamificationController.js";
import { emitToUser } from "../utils/realtime.js";

const ACTIVE_LOAN_LIMIT = 5;

// @route POST /api/transactions/issue  { bookId, userId? }
export const issueBook = asyncHandler(async (req, res) => {
  const { bookId } = req.body;
  const userId = req.user.role === "patron" ? req.user._id : req.body.userId || req.user._id;

  const book = await Book.findById(bookId);
  if (!book) {
    res.status(404);
    throw new Error("Book not found");
  }
  if (book.available < 1) {
    res.status(400);
    throw new Error("No copies currently available");
  }

  const activeLoans = await Transaction.countDocuments({ user: userId, status: { $in: ["issued", "overdue"] } });
  if (activeLoans >= ACTIVE_LOAN_LIMIT) {
    res.status(400);
    throw new Error(`Loan limit reached (${ACTIVE_LOAN_LIMIT} books). Return a book before borrowing another.`);
  }

  const alreadyHas = await Transaction.findOne({ user: userId, book: bookId, status: { $in: ["issued", "overdue"] } });
  if (alreadyHas) {
    res.status(400);
    throw new Error("This copy is already issued to the same patron");
  }

  const transaction = await Transaction.create({
    user: userId,
    book: bookId,
    dueDate: addDays(new Date(), LOAN_PERIOD_DAYS),
  });

  book.available -= 1;
  await book.save();
  await recordActivity(userId);
  emitToUser(userId, "loan:issued", { bookTitle: book.title, dueDate: transaction.dueDate });

  res.status(201).json(transaction);
});

// @route PUT /api/transactions/:id/return
export const returnBook = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findById(req.params.id).populate("book");
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }
  if (transaction.status === "returned") {
    res.status(400);
    throw new Error("This book was already returned");
  }

  const returnDate = new Date();
  const fine = calculateFine(transaction.dueDate, returnDate);

  transaction.returnDate = returnDate;
  transaction.status = "returned";
  transaction.fineAmount = fine;
  await transaction.save();

  const book = await Book.findById(transaction.book._id);
  book.available = Math.min(book.quantity, book.available + 1);
  await book.save();

  if (fine === 0) await awardOnTimeReturn(transaction.user);
  else await recordActivity(transaction.user, { points: 5 });
  emitToUser(transaction.user, "loan:returned", { bookTitle: book.title, fine });

  res.json(transaction);
});

// @route PUT /api/transactions/:id/renew
export const renewBook = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findById(req.params.id);
  if (!transaction || transaction.status === "returned") {
    res.status(404);
    throw new Error("Active transaction not found");
  }
  if (transaction.renewCount >= MAX_RENEWALS) {
    res.status(400);
    throw new Error(`Renewal limit reached (${MAX_RENEWALS})`);
  }
  const overdueFine = calculateFine(transaction.dueDate, new Date());
  if (overdueFine > 0) {
    res.status(400);
    throw new Error("Cannot renew an overdue book - please return and clear the fine first");
  }

  transaction.dueDate = addDays(transaction.dueDate, LOAN_PERIOD_DAYS);
  transaction.renewCount += 1;
  await transaction.save();
  res.json(transaction);
});

// @route GET /api/transactions/mine
export const getMyTransactions = asyncHandler(async (req, res) => {
  const transactions = await Transaction.find({ user: req.user._id })
    .populate("book", "title author coverImage isbn genre")
    .sort("-createdAt");

  // Lazily reflect overdue status + live fine estimate for UI
  const withLiveFine = transactions.map((t) => {
    const obj = t.toObject();
    if (t.status === "issued") {
      const fine = calculateFine(t.dueDate);
      obj.liveFine = fine;
      obj.status = fine > 0 ? "overdue" : "issued";
    }
    return obj;
  });

  res.json(withLiveFine);
});

// @route GET /api/transactions (admin/librarian - all transactions)
export const getAllTransactions = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 15 } = req.query;
  const query = {};
  if (status && status !== "all") query.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [transactions, total] = await Promise.all([
    Transaction.find(query)
      .populate("user", "name email membershipId")
      .populate("book", "title author isbn")
      .sort("-createdAt")
      .skip(skip)
      .limit(Number(limit)),
    Transaction.countDocuments(query),
  ]);

  res.json({ transactions, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
});
