import asyncHandler from "express-async-handler";
import crypto from "crypto";
import Razorpay from "razorpay";
import Transaction from "../models/Transaction.js";
import { calculateFine } from "../utils/fineCalculator.js";
import { logAudit } from "../utils/auditLogger.js";

// Lazily constructed so the server still boots if Razorpay keys aren't set
// yet (only the payment routes will fail until .env is filled in).
const getClient = () => {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    const err = new Error("Payment gateway is not configured — add RAZORPAY_KEY_ID/SECRET to backend/.env");
    err.statusCode = 503;
    throw err;
  }
  return new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
};

// @route POST /api/payments/fine/:transactionId/order
export const createFineOrder = asyncHandler(async (req, res) => {
  const transaction = await Transaction.findOne({ _id: req.params.transactionId, user: req.user._id });
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }

  const currentFine = transaction.status === "returned" ? transaction.fineAmount : calculateFine(transaction.dueDate);
  if (!currentFine || currentFine <= 0) {
    res.status(400);
    throw new Error("No outstanding fine on this loan");
  }
  if (transaction.finePaid) {
    res.status(400);
    throw new Error("Fine already paid");
  }

  const client = getClient();
  const order = await client.orders.create({
    amount: currentFine * 100, // paise
    currency: "INR",
    receipt: `fine_${transaction._id}`,
    notes: { transactionId: transaction._id.toString(), userId: req.user._id.toString() },
  });

  res.json({ order, keyId: process.env.RAZORPAY_KEY_ID, amount: currentFine });
});

// @route POST /api/payments/fine/:transactionId/verify
// Body: { razorpay_order_id, razorpay_payment_id, razorpay_signature }
export const verifyFinePayment = asyncHandler(async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");

  if (expectedSignature !== razorpay_signature) {
    res.status(400);
    throw new Error("Payment verification failed — signature mismatch");
  }

  const transaction = await Transaction.findOne({ _id: req.params.transactionId, user: req.user._id });
  if (!transaction) {
    res.status(404);
    throw new Error("Transaction not found");
  }

  transaction.finePaid = true;
  transaction.paymentId = razorpay_payment_id;
  await transaction.save();

  await logAudit({ user: req.user._id, action: "fine_paid", req, meta: { transactionId: transaction._id.toString(), paymentId: razorpay_payment_id } });

  res.json({ message: "Fine paid successfully", transaction });
});
