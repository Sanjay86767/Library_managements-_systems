import asyncHandler from "express-async-handler";
import { searchFreeBooks, getFreeBookById } from "../utils/gutendexApi.js";

// @route GET /api/free-books/search?q=...&page=1
// Public — anyone worldwide can search public-domain titles, no login needed
export const searchFreeBooksHandler = asyncHandler(async (req, res) => {
  const { q, page = 1 } = req.query;
  if (!q || !q.trim()) {
    res.status(400);
    throw new Error("Search query 'q' is required");
  }
  try {
    const results = await searchFreeBooks(q.trim(), page);
    res.json(results);
  } catch (err) {
    res.status(502);
    throw new Error("Could not reach the free worldwide library right now — please try again shortly");
  }
});

// @route GET /api/free-books/:gutenbergId
export const getFreeBookHandler = asyncHandler(async (req, res) => {
  try {
    const book = await getFreeBookById(req.params.gutenbergId);
    res.json(book);
  } catch (err) {
    res.status(404);
    throw new Error("This free title could not be found");
  }
});
