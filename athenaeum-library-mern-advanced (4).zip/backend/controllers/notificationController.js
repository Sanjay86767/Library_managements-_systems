import asyncHandler from "express-async-handler";
import Notification from "../models/Notification.js";
import Transaction from "../models/Transaction.js";
import { calculateFine } from "../utils/fineCalculator.js";
import { emitToUser } from "../utils/realtime.js";

const DUE_SOON_DAYS = 2;

// Scans the user's active loans and creates any due-soon/overdue alerts that
// don't already exist yet — the unique index on the model makes this safe
// to call on every fetch without creating duplicates.
const generateLoanNotifications = async (userId) => {
  const activeLoans = await Transaction.find({
    user: userId,
    status: { $in: ["issued", "overdue"] },
  }).populate("book", "title");

  const now = new Date();

  for (const loan of activeLoans) {
    if (!loan.book) continue;
    const daysLeft = Math.ceil((new Date(loan.dueDate) - now) / (1000 * 60 * 60 * 24));
    const fine = calculateFine(loan.dueDate, now);

    let doc = null;
    if (fine > 0) {
      doc = {
        type: "overdue",
        title: "Book overdue",
        message: `"${loan.book.title}" is overdue — fine so far is ₹${fine}.`,
      };
    } else if (daysLeft <= DUE_SOON_DAYS) {
      doc = {
        type: "due_soon",
        title: "Due date approaching",
        message: `"${loan.book.title}" is due ${daysLeft <= 0 ? "today" : `in ${daysLeft} day(s)`}.`,
      };
    }
    if (!doc) continue;

    try {
      const created = await Notification.create({
        user: userId,
        relatedTransaction: loan._id,
        link: "/dashboard",
        ...doc,
      });
      // Push straight to any open tab for this user instead of waiting for
      // their next poll cycle.
      emitToUser(userId, "notification:new", created);
    } catch (err) {
      if (err.code !== 11000) throw err; // duplicate = already generated, ignore
    }
  }
};

// @route GET /api/notifications/mine
export const getMyNotifications = asyncHandler(async (req, res) => {
  await generateLoanNotifications(req.user._id);
  const notifications = await Notification.find({ user: req.user._id }).sort("-createdAt").limit(50);
  const unreadCount = await Notification.countDocuments({ user: req.user._id, read: false });
  res.json({ notifications, unreadCount });
});

// @route PUT /api/notifications/:id/read
export const markNotificationRead = asyncHandler(async (req, res) => {
  const notif = await Notification.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    { read: true },
    { new: true }
  );
  if (!notif) {
    res.status(404);
    throw new Error("Notification not found");
  }
  res.json(notif);
});

// @route PUT /api/notifications/read-all
export const markAllNotificationsRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, read: false }, { read: true });
  res.json({ message: "All notifications marked as read" });
});
