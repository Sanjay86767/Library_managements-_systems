import asyncHandler from "express-async-handler";
import Wishlist from "../models/Wishlist.js";
import Book from "../models/Book.js";

// @route POST /api/wishlist  { bookId }  OR  { freeBook: { gutenbergId, title, author, coverUrl, readUrl } }
export const addToWishlist = asyncHandler(async (req, res) => {
  const { bookId, freeBook } = req.body;

  if (bookId) {
    const book = await Book.findById(bookId);
    if (!book) {
      res.status(404);
      throw new Error("Book not found");
    }
    const item = await Wishlist.findOneAndUpdate(
      { user: req.user._id, book: bookId },
      { user: req.user._id, source: "catalog", book: bookId },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    return res.status(201).json(item);
  }

  if (freeBook?.gutenbergId) {
    const item = await Wishlist.findOneAndUpdate(
      { user: req.user._id, "freeBook.gutenbergId": freeBook.gutenbergId },
      { user: req.user._id, source: "free", freeBook },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    return res.status(201).json(item);
  }

  res.status(400);
  throw new Error("Provide either bookId or freeBook details");
});

// @route DELETE /api/wishlist/:id
export const removeFromWishlist = asyncHandler(async (req, res) => {
  const item = await Wishlist.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!item) {
    res.status(404);
    throw new Error("Wishlist item not found");
  }
  res.json({ message: "Removed from wishlist" });
});

// @route GET /api/wishlist/mine
export const getMyWishlist = asyncHandler(async (req, res) => {
  const items = await Wishlist.find({ user: req.user._id })
    .populate("book")
    .sort("-createdAt");
  res.json(items);
});
