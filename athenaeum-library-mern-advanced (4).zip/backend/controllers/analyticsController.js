import asyncHandler from "express-async-handler";
import Transaction from "../models/Transaction.js";
import Book from "../models/Book.js";
import Review from "../models/Review.js";

// @route GET /api/analytics/overview  (admin/librarian)
export const getAnalyticsOverview = asyncHandler(async (req, res) => {
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
  sixMonthsAgo.setDate(1);
  sixMonthsAgo.setHours(0, 0, 0, 0);

  const [monthlyIssued, monthlyReturned, topBorrowers, byGenre, fineStats, topRated, reviewCount] = await Promise.all([
    Transaction.aggregate([
      { $match: { issueDate: { $gte: sixMonthsAgo } } },
      { $group: { _id: { y: { $year: "$issueDate" }, m: { $month: "$issueDate" } }, count: { $sum: 1 } } },
      { $sort: { "_id.y": 1, "_id.m": 1 } },
    ]),
    Transaction.aggregate([
      { $match: { returnDate: { $gte: sixMonthsAgo } } },
      { $group: { _id: { y: { $year: "$returnDate" }, m: { $month: "$returnDate" } }, count: { $sum: 1 } } },
      { $sort: { "_id.y": 1, "_id.m": 1 } },
    ]),
    Transaction.aggregate([
      { $group: { _id: "$user", loanCount: { $sum: 1 } } },
      { $sort: { loanCount: -1 } },
      { $limit: 5 },
      { $lookup: { from: "users", localField: "_id", foreignField: "_id", as: "user" } },
      { $unwind: "$user" },
      { $project: { loanCount: 1, "user.name": 1, "user.membershipId": 1 } },
    ]),
    Book.aggregate([{ $group: { _id: "$genre", count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
    Transaction.aggregate([
      { $match: { fineAmount: { $gt: 0 } } },
      { $group: { _id: null, total: { $sum: "$fineAmount" }, paid: { $sum: { $cond: ["$finePaid", "$fineAmount", 0] } } } },
    ]),
    Book.find({ reviewCount: { $gt: 0 } }).sort("-rating -reviewCount").limit(5).select("title author rating reviewCount"),
    Review.countDocuments(),
  ]);

  const monthLabel = (y, m) => new Date(y, m - 1).toLocaleString("default", { month: "short", year: "2-digit" });
  const trend = monthlyIssued.map((row) => {
    const label = monthLabel(row._id.y, row._id.m);
    const returned = monthlyReturned.find((r) => r._id.y === row._id.y && r._id.m === row._id.m);
    return { month: label, issued: row.count, returned: returned?.count || 0 };
  });

  res.json({
    trend,
    topBorrowers: topBorrowers.map((b) => ({ name: b.user.name, membershipId: b.user.membershipId, loanCount: b.loanCount })),
    byGenre,
    fines: { total: fineStats[0]?.total || 0, paid: fineStats[0]?.paid || 0, outstanding: (fineStats[0]?.total || 0) - (fineStats[0]?.paid || 0) },
    topRated,
    reviewCount,
  });
});
