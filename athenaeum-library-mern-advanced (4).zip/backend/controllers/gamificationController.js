import asyncHandler from "express-async-handler";
import User from "../models/User.js";
import Transaction from "../models/Transaction.js";

const POINTS_PER_BORROW = 10;
const POINTS_PER_RETURN_ON_TIME = 15;

const BADGE_DEFS = [
  { key: "first_loan", label: "First Chapter", test: ({ booksRead }) => booksRead >= 1 },
  { key: "bookworm_5", label: "Bookworm", test: ({ booksRead }) => booksRead >= 5 },
  { key: "bookworm_25", label: "Voracious Reader", test: ({ booksRead }) => booksRead >= 25 },
  { key: "genre_explorer", label: "Genre Explorer", test: ({ genreCount }) => genreCount >= 5 },
  { key: "streak_7", label: "Week-long Streak", test: ({ streak }) => streak >= 7 },
  { key: "streak_30", label: "Monthly Devotee", test: ({ streak }) => streak >= 30 },
  { key: "century_club", label: "Century Club", test: ({ points }) => points >= 100 },
];

const isSameDay = (a, b) => a && b && new Date(a).toDateString() === new Date(b).toDateString();
const isYesterday = (last, now) => {
  if (!last) return false;
  const y = new Date(now);
  y.setDate(y.getDate() - 1);
  return new Date(last).toDateString() === y.toDateString();
};

// Called whenever a patron issues or returns a book — updates their streak
// and points, then re-checks badge thresholds. Silently no-ops on error so
// it never blocks the underlying loan/return transaction.
export const recordActivity = async (userId, { points = POINTS_PER_BORROW } = {}) => {
  try {
    const user = await User.findById(userId);
    if (!user) return;

    const now = new Date();
    if (isSameDay(user.lastActivityDate, now)) {
      // Already active today — points still count, streak untouched.
    } else if (isYesterday(user.lastActivityDate, now)) {
      user.currentStreak += 1;
    } else {
      user.currentStreak = 1;
    }
    user.lastActivityDate = now;
    user.longestStreak = Math.max(user.longestStreak, user.currentStreak);
    user.points += points;

    const history = await Transaction.find({ user: userId }).populate("book", "genre");
    const booksRead = history.filter((t) => t.status === "returned").length + 1; // +1 for current action
    const genreCount = new Set(history.map((t) => t.book?.genre).filter(Boolean)).size;

    const earnedKeys = new Set(user.badges.map((b) => b.key));
    for (const def of BADGE_DEFS) {
      if (!earnedKeys.has(def.key) && def.test({ booksRead, genreCount, streak: user.currentStreak, points: user.points })) {
        user.badges.push({ key: def.key, label: def.label });
      }
    }

    await user.save();
  } catch (err) {
    console.error("Gamification update failed:", err.message);
  }
};

export const awardOnTimeReturn = (userId) => recordActivity(userId, { points: POINTS_PER_RETURN_ON_TIME });

// @route GET /api/gamification/mine
export const getMyGamification = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select("points currentStreak longestStreak badges");
  const allBadges = BADGE_DEFS.map((d) => ({
    key: d.key,
    label: d.label,
    earned: user.badges.some((b) => b.key === d.key),
  }));
  res.json({
    points: user.points,
    currentStreak: user.currentStreak,
    longestStreak: user.longestStreak,
    badges: allBadges,
  });
});

// @route GET /api/gamification/leaderboard
export const getLeaderboard = asyncHandler(async (req, res) => {
  const top = await User.find({ role: "patron" })
    .select("name points currentStreak badges")
    .sort("-points")
    .limit(10);
  res.json(top);
});
