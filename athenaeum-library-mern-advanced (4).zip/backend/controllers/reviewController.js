import asyncHandler from "express-async-handler";
import Review from "../models/Review.js";
import Book from "../models/Book.js";

const recalcBookRating = async (bookId) => {
  const stats = await Review.aggregate([
    { $match: { book: bookId } },
    { $group: { _id: null, avg: { $avg: "$rating" }, count: { $sum: 1 } } },
  ]);
  const avg = stats[0]?.avg || 0;
  const count = stats[0]?.count || 0;
  await Book.findByIdAndUpdate(bookId, { rating: Math.round(avg * 10) / 10, reviewCount: count });
};

// @route POST /api/books/:id/reviews  { rating, comment }
// Re-reviewing the same book updates the patron's existing review instead
// of creating a duplicate.
export const createReview = asyncHandler(async (req, res) => {
  const { rating, comment } = req.body;
  if (!rating || rating < 1 || rating > 5) {
    res.status(400);
    throw new Error("Rating must be between 1 and 5");
  }

  const book = await Book.findById(req.params.id);
  if (!book) {
    res.status(404);
    throw new Error("Book not found");
  }

  const review = await Review.findOneAndUpdate(
    { book: req.params.id, user: req.user._id },
    { rating, comment: comment || "", book: req.params.id, user: req.user._id },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  await recalcBookRating(review.book);
  res.status(201).json(review);
});

// @route GET /api/books/:id/reviews
export const getBookReviews = asyncHandler(async (req, res) => {
  const reviews = await Review.find({ book: req.params.id })
    .populate("user", "name")
    .sort("-createdAt");
  res.json(reviews);
});

// @route GET /api/reviews/feed  — latest reviews across the whole community
export const getReviewFeed = asyncHandler(async (req, res) => {
  const reviews = await Review.find({})
    .populate("user", "name")
    .populate("book", "title author coverImage")
    .sort("-createdAt")
    .limit(30);
  res.json(reviews);
});

// @route DELETE /api/reviews/:id  (own review, or admin/librarian moderation)
export const deleteReview = asyncHandler(async (req, res) => {
  const review = await Review.findById(req.params.id);
  if (!review) {
    res.status(404);
    throw new Error("Review not found");
  }
  const isOwner = review.user.toString() === req.user._id.toString();
  const isStaff = ["admin", "librarian"].includes(req.user.role);
  if (!isOwner && !isStaff) {
    res.status(403);
    throw new Error("Not authorized to delete this review");
  }

  const bookId = review.book;
  await review.deleteOne();
  await recalcBookRating(bookId);
  res.json({ message: "Review removed" });
});
