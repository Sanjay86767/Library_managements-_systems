import asyncHandler from "express-async-handler";
import User from "../models/User.js";

// @route GET /api/users (admin only)
export const getUsers = asyncHandler(async (req, res) => {
  const users = await User.find().select("-password").sort("-joinedAt");
  res.json(users);
});

// @route PUT /api/users/:id/role (admin only)
export const updateUserRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  user.role = role;
  await user.save();
  res.json(user.toSafeObject());
});

// @route PUT /api/users/:id/status (admin only) - activate/deactivate
export const toggleUserStatus = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  user.isActive = !user.isActive;
  await user.save();
  res.json(user.toSafeObject());
});
