import asyncHandler from "express-async-handler";
import Book from "../models/Book.js";
import Transaction from "../models/Transaction.js";
import { logAudit } from "../utils/auditLogger.js";

const SORT_MAP = {
  newest: "-createdAt",
  rating: "-rating -reviewCount",
  available: "-available",
  title: "title",
};

// @route GET /api/books  (search, filter, paginate)
export const getBooks = asyncHandler(async (req, res) => {
  const { search, genre, author, available, page = 1, limit = 12, sort = "newest" } = req.query;

  const query = {};
  if (search) query.$text = { $search: search };
  if (genre && genre !== "all") query.genre = genre;
  if (author) query.author = new RegExp(author, "i");
  if (available === "true") query.available = { $gt: 0 };

  const skip = (Number(page) - 1) * Number(limit);
  const sortExpr = SORT_MAP[sort] || SORT_MAP.newest;

  const [books, total, genres] = await Promise.all([
    Book.find(query).sort(sortExpr).skip(skip).limit(Number(limit)),
    Book.countDocuments(query),
    Book.distinct("genre"),
  ]);

  res.json({
    books,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    genres,
  });
});

// @route GET /api/books/recommendations/mine — genre-based, from borrowing history
export const getRecommendations = asyncHandler(async (req, res) => {
  const history = await Transaction.find({ user: req.user._id }).populate("book", "genre");

  const genreCounts = {};
  const readBookIds = new Set();
  history.forEach((t) => {
    if (!t.book) return;
    readBookIds.add(t.book._id.toString());
    genreCounts[t.book.genre] = (genreCounts[t.book.genre] || 0) + 1;
  });

  const topGenres = Object.entries(genreCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([g]) => g);

  let recommendations = [];
  if (topGenres.length > 0) {
    recommendations = await Book.find({
      genre: { $in: topGenres },
      _id: { $nin: Array.from(readBookIds) },
    })
      .sort("-rating -available")
      .limit(8);
  }

  // Fallback for new patrons with no borrowing history yet: just the
  // highest-rated titles in the catalog.
  if (recommendations.length === 0) {
    recommendations = await Book.find({ _id: { $nin: Array.from(readBookIds) } })
      .sort("-rating -createdAt")
      .limit(8);
  }

  res.json({ recommendations, basedOnGenres: topGenres });
});

export const getBookById = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    res.status(404);
    throw new Error("Book not found");
  }
  res.json(book);
});

// @route POST /api/books (admin/librarian)
export const createBook = asyncHandler(async (req, res) => {
  const { quantity = 1 } = req.body;
  const book = await Book.create({
    ...req.body,
    available: quantity,
    addedBy: req.user._id,
  });
  res.status(201).json(book);
});

// @route PUT /api/books/:id
export const updateBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    res.status(404);
    throw new Error("Book not found");
  }

  const prevQuantity = book.quantity;
  Object.assign(book, req.body);

  // Keep 'available' consistent if quantity changed manually
  if (req.body.quantity !== undefined && req.body.quantity !== prevQuantity) {
    const diff = req.body.quantity - prevQuantity;
    book.available = Math.max(0, book.available + diff);
  }

  await book.save();
  res.json(book);
});

export const deleteBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    res.status(404);
    throw new Error("Book not found");
  }
  await book.deleteOne();
  await logAudit({ user: req.user._id, action: "book_deleted", req, meta: { title: book.title, isbn: book.isbn } });
  res.json({ message: "Book removed from catalog" });
});

// @route GET /api/books/stats/overview (admin dashboard analytics)
export const getBookStats = asyncHandler(async (req, res) => {
  const totalTitles = await Book.countDocuments();
  const totalCopies = await Book.aggregate([{ $group: { _id: null, sum: { $sum: "$quantity" } } }]);
  const totalAvailable = await Book.aggregate([{ $group: { _id: null, sum: { $sum: "$available" } } }]);
  const byGenre = await Book.aggregate([{ $group: { _id: "$genre", count: { $sum: 1 } } }, { $sort: { count: -1 } }]);

  res.json({
    totalTitles,
    totalCopies: totalCopies[0]?.sum || 0,
    totalAvailable: totalAvailable[0]?.sum || 0,
    totalIssued: (totalCopies[0]?.sum || 0) - (totalAvailable[0]?.sum || 0),
    byGenre,
  });
});
