import asyncHandler from "express-async-handler";
import AuditLog from "../models/AuditLog.js";

// @route GET /api/audit-logs?action=&page=&limit=
export const getAuditLogs = asyncHandler(async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Number(req.query.limit) || 50);
  const filter = {};
  if (req.query.action) filter.action = req.query.action;
  if (req.query.email) filter.email = new RegExp(req.query.email, "i");

  const [logs, total, distinctActions] = await Promise.all([
    AuditLog.find(filter)
      .populate("user", "name email role")
      .sort("-createdAt")
      .skip((page - 1) * limit)
      .limit(limit),
    AuditLog.countDocuments(filter),
    AuditLog.distinct("action"),
  ]);

  res.json({ logs, total, page, pages: Math.ceil(total / limit), actions: distinctActions.sort() });
});
