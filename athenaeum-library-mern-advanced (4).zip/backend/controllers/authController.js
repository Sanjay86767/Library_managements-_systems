import jwt from "jsonwebtoken";
import crypto from "crypto";
import asyncHandler from "express-async-handler";
import { authenticator } from "otplib";
import QRCode from "qrcode";
import User from "../models/User.js";
import { sendEmail } from "../utils/sendEmail.js";
import { resetPasswordEmail } from "../utils/emailTemplates.js";
import { logAudit } from "../utils/auditLogger.js";

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

const genToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });

// Short-lived token identifying "password was correct, 2FA code still
// owed" — deliberately NOT a full auth token: it carries a distinct
// `stage` claim so it can't be replayed against protected routes even if
// intercepted, and it expires quickly.
const genPreAuthToken = (id) => jwt.sign({ id, stage: "pre2fa" }, process.env.JWT_SECRET, { expiresIn: "10m" });

// @route POST /api/auth/register
export const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Please provide name, email and password");
  }

  const exists = await User.findOne({ email });
  if (exists) {
    res.status(400);
    throw new Error("An account with this email already exists");
  }

  // First registered user becomes admin automatically (bootstrap), rest are patrons
  const userCount = await User.countDocuments();
  const role = userCount === 0 ? "admin" : "patron";

  const user = await User.create({ name, email, password, phone, role });
  await logAudit({ user: user._id, email, action: "register", req });

  res.status(201).json({
    ...user.toSafeObject(),
    token: genToken(user._id),
  });
});

// @route POST /api/auth/login
export const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select("+lockUntil +failedLoginAttempts");

  if (user?.lockUntil && user.lockUntil > Date.now()) {
    const minutesLeft = Math.ceil((user.lockUntil - Date.now()) / 60000);
    await logAudit({ user: user._id, email, action: "login_blocked_locked", req });
    res.status(423);
    throw new Error(`Too many failed attempts. Try again in ${minutesLeft} minute(s).`);
  }

  const passwordOk = user && (await user.matchPassword(password));

  if (!passwordOk) {
    if (user) {
      user.failedLoginAttempts += 1;
      if (user.failedLoginAttempts >= MAX_FAILED_ATTEMPTS) {
        user.lockUntil = new Date(Date.now() + LOCK_DURATION_MS);
      }
      await user.save({ validateBeforeSave: false });
      await logAudit({ user: user._id, email, action: "login_failed", req, meta: { attempts: user.failedLoginAttempts } });
    } else {
      await logAudit({ email, action: "login_failed_unknown_email", req });
    }
    res.status(401);
    throw new Error("Invalid email or password");
  }

  // Correct password — reset the failure counter regardless of what
  // happens next (2FA or not).
  user.failedLoginAttempts = 0;
  user.lockUntil = null;
  await user.save({ validateBeforeSave: false });

  if (user.twoFactorEnabled) {
    await logAudit({ user: user._id, email, action: "login_password_ok_awaiting_2fa", req });
    return res.json({ requires2FA: true, tempToken: genPreAuthToken(user._id) });
  }

  await logAudit({ user: user._id, email, action: "login_success", req });
  res.json({ ...user.toSafeObject(), token: genToken(user._id) });
});

// @route POST /api/auth/2fa/login-verify   { tempToken, token }
// Second step of login once 2FA is enabled — exchanges the short-lived
// pre-auth token plus a valid TOTP code for a real session token.
export const verifyLogin2FA = asyncHandler(async (req, res) => {
  const { tempToken, token } = req.body;
  if (!tempToken || !token) {
    res.status(400);
    throw new Error("Missing verification code");
  }

  let decoded;
  try {
    decoded = jwt.verify(tempToken, process.env.JWT_SECRET);
  } catch {
    res.status(401);
    throw new Error("Your login attempt expired — please sign in again");
  }
  if (decoded.stage !== "pre2fa") {
    res.status(401);
    throw new Error("Invalid verification session");
  }

  const user = await User.findById(decoded.id).select("+twoFactorSecret");
  if (!user || !user.twoFactorEnabled || !user.twoFactorSecret) {
    res.status(400);
    throw new Error("Two-factor authentication is not set up on this account");
  }

  const valid = authenticator.verify({ token, secret: user.twoFactorSecret });
  if (!valid) {
    await logAudit({ user: user._id, action: "login_2fa_failed", req });
    res.status(401);
    throw new Error("Invalid or expired authentication code");
  }

  await logAudit({ user: user._id, action: "login_2fa_success", req });
  res.json({ ...user.toSafeObject(), token: genToken(user._id) });
});

// @route GET /api/auth/me
export const getMe = asyncHandler(async (req, res) => {
  res.json(req.user);
});

// @route POST /api/auth/2fa/setup   (logged in, not yet enabled)
// Generates a fresh TOTP secret and returns a scannable QR code. The
// secret is stashed as "pending" until the user proves they scanned it
// correctly via verify-setup — this avoids ever locking someone out of
// their own account with a secret they never actually saved.
export const setup2FA = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (user.twoFactorEnabled) {
    res.status(400);
    throw new Error("Two-factor authentication is already enabled");
  }

  const secret = authenticator.generateSecret();
  user.twoFactorPendingSecret = secret;
  await user.save({ validateBeforeSave: false });

  const otpauth = authenticator.keyuri(user.email, "Athenaeum Library", secret);
  const qrCode = await QRCode.toDataURL(otpauth);

  res.json({ qrCode, secret });
});

// @route POST /api/auth/2fa/verify-setup   { token }
export const verifySetup2FA = asyncHandler(async (req, res) => {
  const { token } = req.body;
  const user = await User.findById(req.user._id).select("+twoFactorPendingSecret");

  if (!user.twoFactorPendingSecret) {
    res.status(400);
    throw new Error("Start setup first by requesting a QR code");
  }

  const valid = authenticator.verify({ token, secret: user.twoFactorPendingSecret });
  if (!valid) {
    res.status(400);
    throw new Error("That code didn't match — check your authenticator app and try again");
  }

  user.twoFactorSecret = user.twoFactorPendingSecret;
  user.twoFactorPendingSecret = undefined;
  user.twoFactorEnabled = true;
  await user.save({ validateBeforeSave: false });

  await logAudit({ user: user._id, action: "2fa_enabled", req });
  res.json({ message: "Two-factor authentication is now enabled on your account" });
});

// @route POST /api/auth/2fa/disable   { password }
export const disable2FA = asyncHandler(async (req, res) => {
  const { password } = req.body;
  const user = await User.findById(req.user._id);

  const matches = await user.matchPassword(password || "");
  if (!matches) {
    res.status(401);
    throw new Error("Password is incorrect");
  }

  user.twoFactorEnabled = false;
  user.twoFactorSecret = undefined;
  user.twoFactorPendingSecret = undefined;
  await user.save({ validateBeforeSave: false });

  await logAudit({ user: user._id, action: "2fa_disabled", req });
  res.json({ message: "Two-factor authentication has been disabled" });
});

// @route POST /api/auth/forgot-password  { email }
// Always responds with the same generic message, whether or not the email
// exists — this stops outsiders from using the endpoint to check who has
// an account here.
export const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.status(400);
    throw new Error("Please provide an email address");
  }

  const genericMessage = "If an account with that email exists, a reset link has been sent.";
  const user = await User.findOne({ email });

  if (user) {
    const rawToken = user.generatePasswordResetToken();
    await user.save({ validateBeforeSave: false });

    const resetUrl = `${process.env.CLIENT_URL || "http://localhost:5173"}/reset-password/${rawToken}`;

    try {
      await sendEmail({
        to: user.email,
        subject: "Reset your Athenaeum Library password",
        html: resetPasswordEmail(user.name, resetUrl),
      });
      await logAudit({ user: user._id, email, action: "password_reset_requested", req });
    } catch (err) {
      // Don't leak email-sending failures to the client, but don't leave a
      // dangling reset token either.
      user.resetPasswordToken = undefined;
      user.resetPasswordExpire = undefined;
      await user.save({ validateBeforeSave: false });
      res.status(500);
      throw new Error("Email could not be sent, please try again later");
    }
  }

  res.json({ message: genericMessage });
});

// @route PUT /api/auth/reset-password/:token  { password }
export const resetPassword = asyncHandler(async (req, res) => {
  const { password } = req.body;
  if (!password || password.length < 6) {
    res.status(400);
    throw new Error("Password must be at least 6 characters");
  }

  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

  const user = await User.findOne({
    resetPasswordToken: hashedToken,
    resetPasswordExpire: { $gt: Date.now() },
  }).select("+resetPasswordToken +resetPasswordExpire");

  if (!user) {
    res.status(400);
    throw new Error("This reset link is invalid or has expired");
  }

  user.password = password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpire = undefined;
  await user.save();

  await logAudit({ user: user._id, action: "password_reset_completed", req });

  res.json({
    ...user.toSafeObject(),
    token: genToken(user._id),
  });
});

// @route PUT /api/auth/change-password  { currentPassword, newPassword }
// For a logged-in user who knows their current password (different from the
// forgot-password flow, which is for when they don't).
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    res.status(400);
    throw new Error("Provide your current and new password");
  }
  if (newPassword.length < 6) {
    res.status(400);
    throw new Error("New password must be at least 6 characters");
  }

  const user = await User.findById(req.user._id);
  const matches = await user.matchPassword(currentPassword);
  if (!matches) {
    res.status(401);
    throw new Error("Current password is incorrect");
  }

  user.password = newPassword;
  await user.save();
  await logAudit({ user: user._id, action: "password_changed", req });
  res.json({ message: "Password updated successfully" });
});
