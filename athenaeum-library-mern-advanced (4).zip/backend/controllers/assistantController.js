import asyncHandler from "express-async-handler";
import Book from "../models/Book.js";

const SYSTEM_PROMPT = `You are Athenaeum, a warm and knowledgeable AI librarian for a library
management system. You help patrons discover books, explain genres, suggest
what to read next, and answer general questions about reading. Keep replies
under 120 words, friendly and concise. If the patron's own catalog is given
to you as context, prefer recommending titles from it before suggesting books
outside the collection. You are not able to place holds or issue books
yourself — direct the patron to the "Browse catalog" tab to actually borrow
a title.`;

// @route POST /api/assistant/ask   { message, history? }
export const askAssistant = asyncHandler(async (req, res) => {
  if (!process.env.ANTHROPIC_API_KEY) {
    res.status(503);
    throw new Error("AI librarian is not configured — add ANTHROPIC_API_KEY to backend/.env");
  }

  const { message, history = [] } = req.body;
  if (!message || !message.trim()) {
    res.status(400);
    throw new Error("Message is required");
  }

  // Give the model a little grounding in what's actually in the catalog so
  // it doesn't recommend titles the library doesn't have.
  const sample = await Book.find({ available: { $gt: 0 } })
    .sort("-rating")
    .limit(25)
    .select("title author genre rating -_id");
  const catalogContext = sample.map((b) => `${b.title} by ${b.author} (${b.genre}, ${b.rating}★)`).join("\n");

  const messages = [
    ...history.slice(-6).map((h) => ({ role: h.role === "assistant" ? "assistant" : "user", content: h.content })),
    { role: "user", content: message },
  ];

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-5",
      max_tokens: 400,
      system: `${SYSTEM_PROMPT}\n\nSample of currently available catalog titles:\n${catalogContext}`,
      messages,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    console.error("Anthropic API error:", errText);
    res.status(502);
    throw new Error("The AI librarian is unavailable right now — please try again shortly.");
  }

  const data = await response.json();
  const reply = data.content?.find((b) => b.type === "text")?.text || "Sorry, I couldn't come up with a reply.";
  res.json({ reply });
});
