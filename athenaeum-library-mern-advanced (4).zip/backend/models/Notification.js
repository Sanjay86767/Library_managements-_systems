import mongoose from "mongoose";

const notificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    type: { type: String, enum: ["due_soon", "overdue", "wishlist_available"], required: true },
    title: { type: String, required: true },
    message: { type: String, required: true },
    link: { type: String, default: "" },
    relatedTransaction: { type: mongoose.Schema.Types.ObjectId, ref: "Transaction" },
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Stops the same due-date/overdue alert being generated twice for one loan
notificationSchema.index(
  { user: 1, relatedTransaction: 1, type: 1 },
  { unique: true, partialFilterExpression: { relatedTransaction: { $exists: true } } }
);

export default mongoose.model("Notification", notificationSchema);
