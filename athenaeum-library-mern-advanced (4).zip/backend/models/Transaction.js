import mongoose from "mongoose";

const transactionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    book: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
    issueDate: { type: Date, default: Date.now },
    dueDate: { type: Date, required: true },
    returnDate: { type: Date, default: null },
    status: {
      type: String,
      enum: ["issued", "returned", "overdue", "lost"],
      default: "issued",
    },
    fineAmount: { type: Number, default: 0 },
    finePaid: { type: Boolean, default: false },
    paymentId: { type: String, default: null },
    renewCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

transactionSchema.index({ user: 1, status: 1 });
transactionSchema.index({ book: 1, status: 1 });

export default mongoose.model("Transaction", transactionSchema);
