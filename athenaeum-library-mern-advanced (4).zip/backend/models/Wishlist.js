import mongoose from "mongoose";

const wishlistSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    // "catalog" = a book in our own physical library; "free" = a public-domain
    // title from the worldwide free library (Project Gutenberg)
    source: { type: String, enum: ["catalog", "free"], required: true },
    book: { type: mongoose.Schema.Types.ObjectId, ref: "Book" },
    freeBook: {
      gutenbergId: Number,
      title: String,
      author: String,
      coverUrl: String,
      readUrl: String,
    },
  },
  { timestamps: true }
);

// Prevent duplicate wishlist entries per user, for either kind of item
wishlistSchema.index(
  { user: 1, book: 1 },
  { unique: true, partialFilterExpression: { book: { $exists: true } } }
);
wishlistSchema.index(
  { user: 1, "freeBook.gutenbergId": 1 },
  { unique: true, partialFilterExpression: { "freeBook.gutenbergId": { $exists: true } } }
);

export default mongoose.model("Wishlist", wishlistSchema);
