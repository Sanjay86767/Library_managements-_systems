import mongoose from "mongoose";

const bookSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, index: true },
    author: { type: String, required: true, trim: true, index: true },
    isbn: { type: String, required: true, unique: true },
    genre: { type: String, default: "General", index: true },
    description: { type: String, default: "" },
    coverImage: { type: String, default: "" }, // Cloudinary URL
    publishedYear: { type: Number },
    publisher: { type: String },
    quantity: { type: Number, required: true, default: 1, min: 0 },
    available: { type: Number, required: true, default: 1, min: 0 },
    shelfLocation: { type: String, default: "General Stack" },
    rating: { type: Number, default: 0, min: 0, max: 5 },
    reviewCount: { type: Number, default: 0 },
    tags: [{ type: String }],
    addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

bookSchema.index({ title: "text", author: "text", genre: "text", tags: "text" });

bookSchema.virtual("isAvailable").get(function () {
  return this.available > 0;
});
bookSchema.set("toJSON", { virtuals: true });

export default mongoose.model("Book", bookSchema);
