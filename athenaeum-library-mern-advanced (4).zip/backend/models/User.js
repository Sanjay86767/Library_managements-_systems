import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["patron", "librarian", "admin"], default: "patron" },
    membershipId: { type: String, unique: true },
    phone: { type: String },
    joinedAt: { type: Date, default: Date.now },
    isActive: { type: Boolean, default: true },
    resetPasswordToken: { type: String, default: undefined, select: false },
    resetPasswordExpire: { type: Date, default: undefined, select: false },

    // Security hardening
    twoFactorEnabled: { type: Boolean, default: false },
    twoFactorSecret: { type: String, default: undefined, select: false },
    twoFactorPendingSecret: { type: String, default: undefined, select: false },
    failedLoginAttempts: { type: Number, default: 0 },
    lockUntil: { type: Date, default: null, select: false },

    // Gamification
    points: { type: Number, default: 0 },
    currentStreak: { type: Number, default: 0 },
    longestStreak: { type: Number, default: 0 },
    lastActivityDate: { type: Date, default: null },
    badges: [{
      key: String,
      label: String,
      earnedAt: { type: Date, default: Date.now },
    }],
  },
  { timestamps: true }
);

userSchema.pre("save", async function (next) {
  if (!this.membershipId) {
    this.membershipId = "LIB-" + Math.random().toString(36).slice(2, 9).toUpperCase();
  }
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function (entered) {
  return bcrypt.compare(entered, this.password);
};

// Creates a plain token to email the user, but only stores its hash in the DB
// (so a leaked database never exposes usable reset links).
userSchema.methods.generatePasswordResetToken = function () {
  const rawToken = crypto.randomBytes(32).toString("hex");
  this.resetPasswordToken = crypto.createHash("sha256").update(rawToken).digest("hex");
  this.resetPasswordExpire = Date.now() + 30 * 60 * 1000; // 30 minutes
  return rawToken;
};

userSchema.methods.toSafeObject = function () {
  const { _id, name, email, role, membershipId, phone, joinedAt, points, currentStreak, longestStreak, badges, twoFactorEnabled } = this;
  return { _id, name, email, role, membershipId, phone, joinedAt, points, currentStreak, longestStreak, badges, twoFactorEnabled };
};

export default mongoose.model("User", userSchema);
