import { io } from "socket.io-client";

let socket = null;

// Lazily creates (or reuses) a single authenticated socket connection for
// the whole app. Call disconnectSocket() on logout so a stale token isn't
// reused for the next login.
export const getSocket = () => {
  const token = localStorage.getItem("athenaeum_token");
  if (!token) return null;

  if (socket && socket.connected) return socket;

  if (!socket) {
    socket = io("/", {
      auth: { token },
      autoConnect: true,
      transports: ["websocket", "polling"],
    });
  } else {
    socket.auth = { token };
    socket.connect();
  }
  return socket;
};

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
