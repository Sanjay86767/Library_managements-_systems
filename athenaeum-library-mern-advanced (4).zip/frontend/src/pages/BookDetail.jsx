import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api/axios.js";
import { useAuth } from "../context/AuthContext.jsx";
import StarRating from "../components/StarRating.jsx";

const BookDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [book, setBook] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [myRating, setMyRating] = useState(0);
  const [comment, setComment] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [b, r] = await Promise.all([
      api.get(`/books/${id}`),
      api.get(`/books/${id}/reviews`),
    ]);
    setBook(b.data);
    setReviews(r.data);
  };

  useEffect(() => { load(); }, [id]);

  const borrow = async () => {
    if (!user) return setMsg("Sign in to borrow this book.");
    setBusy(true);
    try {
      await api.post("/transactions/issue", { bookId: id });
      setMsg(`"${book.title}" issued — due in 14 days.`);
      load();
    } catch (err) {
      setMsg(err.response?.data?.message || "Could not borrow this book");
    } finally {
      setBusy(false);
    }
  };

  const addToWishlist = async () => {
    if (!user) return setMsg("Sign in to save books to your wishlist.");
    try {
      await api.post("/wishlist", { bookId: id });
      setMsg("Added to your wishlist.");
    } catch (err) {
      setMsg(err.response?.data?.message || "Could not add to wishlist");
    }
  };

  const submitReview = async (e) => {
    e.preventDefault();
    if (!user) return setMsg("Sign in to leave a review.");
    if (myRating < 1) return setMsg("Pick a star rating first.");
    try {
      await api.post(`/books/${id}/reviews`, { rating: myRating, comment });
      setComment("");
      setMyRating(0);
      load();
    } catch (err) {
      setMsg(err.response?.data?.message || "Could not submit review");
    }
  };

  if (!book) return <div className="max-w-4xl mx-auto px-6 py-16 font-ui text-ink/50">Loading…</div>;

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <Link to="/" className="font-ui text-xs text-burgundy underline">← Back to catalog</Link>

      <div className="grid sm:grid-cols-3 gap-8 mt-6">
        <div className="sm:col-span-1">
          <div
            className="h-64 rounded-sm flex items-center justify-center p-6"
            style={{ background: "linear-gradient(160deg, #7A2E2E, #7A2E2ECC)" }}
          >
            <p className="font-display text-white text-center text-lg">{book.title}</p>
          </div>
          <div className="mt-4 space-y-2">
            <button
              disabled={book.available < 1 || busy}
              onClick={borrow}
              className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm disabled:opacity-40 transition-colors"
            >
              {book.available > 0 ? "Borrow this book" : "All copies out"}
            </button>
            <button
              onClick={addToWishlist}
              className="w-full border border-brass/40 font-ui text-sm py-2.5 rounded-sm hover:bg-brass/10 transition-colors"
            >
              ♡ Add to wishlist
            </button>
          </div>
        </div>

        <div className="sm:col-span-2">
          <p className="catalog-label text-xs text-burgundy mb-1">{book.genre}</p>
          <h1 className="font-display text-3xl text-ink mb-1">{book.title}</h1>
          <p className="font-ui text-sm text-ink/60 mb-3">by {book.author}</p>
          <StarRating value={book.rating} count={book.reviewCount} size="text-lg" />
          <p className="font-body text-sm text-ink/70 mt-4 leading-relaxed">{book.description || "No description available."}</p>

          <div className="grid grid-cols-2 gap-3 mt-6 font-ui text-xs text-ink/60">
            <p>ISBN: {book.isbn}</p>
            <p>Publisher: {book.publisher || "—"}</p>
            <p>Published: {book.publishedYear || "—"}</p>
            <p>Shelf: {book.shelfLocation}</p>
            <p>{book.available}/{book.quantity} available</p>
          </div>

          {msg && <p className="font-ui text-sm bg-brass/15 border border-brass/40 px-4 py-3 rounded-sm mt-6">{msg}</p>}

          <div className="mt-10">
            <h2 className="font-display text-2xl text-ink mb-4">Reviews</h2>

            {user && (
              <form onSubmit={submitReview} className="bg-white/60 border border-brass/30 rounded-sm p-4 mb-6">
                <p className="font-ui text-xs text-ink/60 mb-2">Your rating</p>
                <StarRating value={myRating} onRate={setMyRating} size="text-2xl" />
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Share your thoughts (optional)…"
                  rows={3}
                  className="w-full mt-3 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
                />
                <button className="mt-3 bg-ink text-parchment font-ui text-sm px-4 py-2 rounded-sm">
                  Submit review
                </button>
              </form>
            )}

            <div className="space-y-3">
              {reviews.length === 0 && <p className="font-ui text-sm text-ink/50">No reviews yet — be the first.</p>}
              {reviews.map((r) => (
                <div key={r._id} className="border-b border-brass/20 pb-3">
                  <div className="flex items-center gap-2">
                    <p className="font-ui text-sm text-ink font-medium">{r.user?.name || "A patron"}</p>
                    <StarRating value={r.rating} />
                  </div>
                  {r.comment && <p className="font-body text-sm text-ink/70 mt-1">{r.comment}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetail;
