import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios.js";
import BookCard from "../components/BookCard.jsx";
import ChangePasswordForm from "../components/ChangePasswordForm.jsx";
import TwoFactorSetup from "../components/TwoFactorSetup.jsx";
import AchievementsPanel from "../components/AchievementsPanel.jsx";
import BookshelfView from "../components/BookshelfView.jsx";
import AIChatWidget from "../components/AIChatWidget.jsx";
import PayFineButton from "../components/PayFineButton.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";

const statusColor = { issued: "bg-sage/20 text-sage", overdue: "bg-rust/20 text-rust", returned: "bg-ink/10 text-ink/60" };

const PatronDashboard = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [tab, setTab] = useState("browse");
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");
  const [browseView, setBrowseView] = useState("grid"); // grid | shelf
  const [loans, setLoans] = useState([]);
  const [historyQuery, setHistoryQuery] = useState("");
  const [wishlist, setWishlist] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [feed, setFeed] = useState([]);
  const [msg, setMsg] = useState("");
  const [busyId, setBusyId] = useState(null);
  const searchDebounce = useRef(null);

  const fetchBooks = async (params = {}) => {
    const { data } = await api.get("/books", { params: { search: query, limit: 12, sort, ...params } });
    setBooks(data.books);
  };
  const fetchLoans = async () => {
    const { data } = await api.get("/transactions/mine");
    setLoans(data);
  };
  const fetchWishlist = async () => {
    const { data } = await api.get("/wishlist/mine");
    setWishlist(data);
  };
  const fetchRecommendations = async () => {
    const { data } = await api.get("/books/recommendations/mine");
    setRecommendations(data.recommendations);
  };
  const fetchFeed = async () => {
    const { data } = await api.get("/reviews/feed");
    setFeed(data);
  };

  useEffect(() => { fetchBooks(); fetchLoans(); fetchWishlist(); fetchRecommendations(); }, []);
  useEffect(() => { fetchBooks(); }, [sort]);

  // Live search-as-you-type: debounce so we're not hitting the API on
  // every keystroke, but still update without waiting for form submit.
  useEffect(() => {
    if (searchDebounce.current) clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => { fetchBooks(); }, 350);
    return () => clearTimeout(searchDebounce.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => { if (tab === "community" && feed.length === 0) fetchFeed(); }, [tab]);

  const wishlistedBookIds = new Set(wishlist.filter((w) => w.book).map((w) => w.book._id));

  const borrow = async (book) => {
    setBusyId(book._id);
    try {
      await api.post("/transactions/issue", { bookId: book._id });
      setMsg(`Issued "${book.title}" — due in 14 days. +10 reading points!`);
      fetchBooks(); fetchLoans();
    } catch (e) { setMsg(e.response?.data?.message || "Could not borrow"); }
    finally { setBusyId(null); }
  };

  const renew = async (id) => {
    setBusyId(id);
    try { await api.put(`/transactions/${id}/renew`); fetchLoans(); }
    catch (e) { setMsg(e.response?.data?.message || "Could not renew"); }
    finally { setBusyId(null); }
  };

  const toggleWishlist = async (book) => {
    try {
      await api.post("/wishlist", { bookId: book._id });
      fetchWishlist();
    } catch (e) { setMsg(e.response?.data?.message || "Could not update wishlist"); }
  };

  const removeWishlistItem = async (id) => {
    await api.delete(`/wishlist/${id}`);
    fetchWishlist();
  };

  const activeLoans = loans.filter((l) => l.status !== "returned");
  const pastLoans = loans.filter((l) => l.status === "returned");
  const totalFines = loans.reduce((s, l) => s + (l.liveFine || l.fineAmount || 0), 0);

  const filteredHistory = pastLoans.filter((l) =>
    !historyQuery.trim() ||
    l.book?.title?.toLowerCase().includes(historyQuery.toLowerCase()) ||
    l.book?.author?.toLowerCase().includes(historyQuery.toLowerCase())
  );

  const genreCounts = pastLoans.reduce((acc, l) => {
    const g = l.book?.genre;
    if (g) acc[g] = (acc[g] || 0) + 1;
    return acc;
  }, {});
  const topGenre = Object.entries(genreCounts).sort((a, b) => b[1] - a[1])[0]?.[0];

  const TABS = ["browse", "loans", "history", "wishlist", "recommended", "achievements", "community", "account"];
  const TAB_LABELS = {
    browse: t("browseCatalog"),
    loans: `${t("currentLoans")}${totalFines > 0 ? ` · ₹${totalFines} ${t("due")}` : ""}`,
    history: `${t("readingHistory")} (${pastLoans.length})`,
    wishlist: `${t("wishlist")} (${wishlist.length})`,
    recommended: t("recommendedForYou"),
    achievements: t("achievements"),
    community: t("community"),
    account: t("account"),
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <p className="catalog-label text-xs text-burgundy mb-1">Patron desk</p>
      <h1 className="font-display text-4xl text-ink mb-1">{t("welcomeBack")}, {user.name.split(" ")[0]}</h1>
      <p className="font-ui text-sm text-ink/60 mb-8">Card {user.membershipId} · {activeLoans.length} book(s) currently on loan</p>

      <div className="flex gap-3 mb-8 font-ui text-sm flex-wrap">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-sm capitalize transition-colors ${tab === t ? "bg-ink text-parchment" : "bg-white/60 text-ink border border-brass/30"}`}>
            {TAB_LABELS[t]}
          </button>
        ))}
      </div>

      {msg && <div className="mb-6 font-ui text-sm bg-brass/15 border border-brass/40 px-4 py-3 rounded-sm">{msg}</div>}

      {tab === "browse" && (
        <>
          <div className="flex flex-wrap gap-3 mb-6 items-center">
            <form onSubmit={(e) => { e.preventDefault(); fetchBooks(); }} className="flex gap-3 max-w-md flex-1">
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("searchPlaceholder")}
                className="flex-1 px-3 py-2 border border-brass/40 rounded-sm bg-white/70 font-ui text-sm outline-none focus:border-brass" />
            </form>
            <select value={sort} onChange={(e) => setSort(e.target.value)}
              className="font-ui text-sm border border-brass/40 bg-white/70 rounded-sm px-3 py-2">
              <option value="newest">{t("newestFirst")}</option>
              <option value="rating">{t("highestRated")}</option>
              <option value="available">{t("mostAvailable")}</option>
              <option value="title">{t("titleAZ")}</option>
            </select>
            <div className="flex gap-1 bg-white/60 border border-brass/30 rounded-sm p-1">
              <button onClick={() => setBrowseView("grid")}
                className={`px-3 py-1 font-ui text-xs rounded-sm ${browseView === "grid" ? "bg-ink text-parchment" : "text-ink"}`}>{t("grid")}</button>
              <button onClick={() => setBrowseView("shelf")}
                className={`px-3 py-1 font-ui text-xs rounded-sm ${browseView === "shelf" ? "bg-ink text-parchment" : "text-ink"}`}>{t("shelf")}</button>
            </div>
          </div>

          {browseView === "grid" ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {books.map((b, i) => (
                <div key={b._id} className="result-card" style={{ animationDelay: `${i * 30}ms` }}>
                  <BookCard book={b} onBorrow={borrow} borrowing={busyId === b._id}
                    onWishlist={toggleWishlist} wishlisted={wishlistedBookIds.has(b._id)} />
                </div>
              ))}
            </div>
          ) : (
            <BookshelfView books={books} onSelect={(b) => window.open(`/books/${b._id}`, "_self")} />
          )}
        </>
      )}

      {tab === "loans" && (
        <div className="space-y-3">
          {activeLoans.length === 0 && <p className="font-ui text-ink/50">No active loans — browse the catalog to borrow a book.</p>}
          {activeLoans.map((l) => (
            <div key={l._id} className="bg-white/60 border border-brass/30 rounded-sm p-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <p className="font-display text-lg text-ink">{l.book?.title}</p>
                <p className="font-ui text-xs text-ink/60">
                  Issued {new Date(l.issueDate).toLocaleDateString()} · Due {new Date(l.dueDate).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {(l.liveFine || l.fineAmount) > 0 && !l.finePaid && (
                  <>
                    <span className="font-ui text-xs text-rust">₹{l.liveFine || l.fineAmount} fine</span>
                    <PayFineButton transactionId={l._id} amount={l.liveFine || l.fineAmount}
                      patronName={user.name} patronEmail={user.email} onPaid={fetchLoans} />
                  </>
                )}
                <span className={`font-ui text-[11px] px-2 py-1 rounded-full capitalize ${statusColor[l.status] || ""}`}>{l.status}</span>
                <button disabled={busyId === l._id} onClick={() => renew(l._id)}
                  className="font-ui text-xs bg-ink text-parchment px-3 py-1.5 rounded-sm disabled:opacity-40">
                  Renew
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "history" && (
        <div>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <p className="font-ui text-sm text-ink/60">
              {pastLoans.length} book{pastLoans.length === 1 ? "" : "s"} completed
              {topGenre && <> · favourite genre so far: <span className="text-ink">{topGenre}</span></>}
            </p>
            <input value={historyQuery} onChange={(e) => setHistoryQuery(e.target.value)}
              placeholder="Search past reads by title or author…"
              className="px-3 py-2 border border-brass/40 rounded-sm bg-white/70 font-ui text-sm outline-none focus:border-brass w-full sm:w-72" />
          </div>

          {pastLoans.length === 0 && (
            <p className="font-ui text-ink/50">No returned books yet — your reading history will build up here once you return a loan.</p>
          )}
          {pastLoans.length > 0 && filteredHistory.length === 0 && (
            <p className="font-ui text-ink/50">No past reads match "{historyQuery}".</p>
          )}

          <div className="space-y-3">
            {filteredHistory.map((l) => (
              <div key={l._id} className="bg-white/60 border border-brass/30 rounded-sm p-4 flex items-center justify-between flex-wrap gap-3">
                <div>
                  <p className="font-display text-lg text-ink">{l.book?.title}</p>
                  <p className="font-ui text-xs text-ink/60">
                    by {l.book?.author}{l.book?.genre && ` · ${l.book.genre}`}
                  </p>
                  <p className="font-ui text-xs text-ink/50">
                    Borrowed {new Date(l.issueDate).toLocaleDateString()} · Returned {new Date(l.returnDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {l.fineAmount > 0 && (
                    <span className="font-ui text-[11px] px-2 py-1 rounded-full bg-ink/10 text-ink/60">
                      ₹{l.fineAmount} fine {l.finePaid ? "paid" : "due"}
                    </span>
                  )}
                  {l.fineAmount > 0 && !l.finePaid && (
                    <PayFineButton transactionId={l._id} amount={l.fineAmount}
                      patronName={user.name} patronEmail={user.email} onPaid={fetchLoans} />
                  )}
                  {l.book?._id && (
                    <Link to={`/books/${l.book._id}`} className="font-ui text-xs bg-burgundy text-white px-3 py-1.5 rounded-sm">
                      Borrow again
                    </Link>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "wishlist" && (
        <div className="space-y-3">
          {wishlist.length === 0 && <p className="font-ui text-ink/50">Nothing saved yet — heart a book from the catalog or the Free World Library.</p>}
          {wishlist.map((w) => (
            <div key={w._id} className="bg-white/60 border border-brass/30 rounded-sm p-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <p className="font-display text-lg text-ink">{w.book?.title || w.freeBook?.title}</p>
                <p className="font-ui text-xs text-ink/60">
                  {w.book ? `by ${w.book.author} · catalog title` : `by ${w.freeBook?.author} · free worldwide title`}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {w.source === "catalog" ? (
                  <Link to={`/books/${w.book?._id}`} className="font-ui text-xs bg-burgundy text-white px-3 py-1.5 rounded-sm">View</Link>
                ) : (
                  <a href={w.freeBook?.readUrl} target="_blank" rel="noopener noreferrer"
                    className="font-ui text-xs bg-burgundy text-white px-3 py-1.5 rounded-sm">Read free</a>
                )}
                <button onClick={() => removeWishlistItem(w._id)}
                  className="font-ui text-xs border border-rust/40 text-rust px-3 py-1.5 rounded-sm">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "recommended" && (
        <div>
          <p className="font-ui text-sm text-ink/60 mb-6">Based on the genres you've borrowed most.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommendations.map((b) => (
              <BookCard key={b._id} book={b} onBorrow={borrow} borrowing={busyId === b._id}
                onWishlist={toggleWishlist} wishlisted={wishlistedBookIds.has(b._id)} />
            ))}
          </div>
          {recommendations.length === 0 && <p className="font-ui text-ink/50">No recommendations yet — borrow a few books first.</p>}
        </div>
      )}

      {tab === "achievements" && <AchievementsPanel />}

      {tab === "community" && (
        <div className="space-y-3">
          <p className="font-ui text-sm text-ink/60 mb-3">What fellow patrons are reading and rating right now.</p>
          {feed.length === 0 && <p className="font-ui text-ink/50">No community reviews yet — be the first to leave one on a book's page.</p>}
          {feed.map((r) => (
            <div key={r._id} className="bg-white/60 border border-brass/30 rounded-sm p-4">
              <div className="flex items-center justify-between mb-1">
                <p className="font-ui text-sm text-ink"><span className="font-semibold">{r.user?.name}</span> reviewed <Link to={`/books/${r.book?._id}`} className="text-burgundy underline">{r.book?.title}</Link></p>
                <span className="font-ui text-xs text-brass">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</span>
              </div>
              {r.comment && <p className="font-ui text-sm text-ink/70">{r.comment}</p>}
            </div>
          ))}
        </div>
      )}

      {tab === "account" && (
        <div className="space-y-6">
          <ChangePasswordForm />
          <TwoFactorSetup />
        </div>
      )}

      <AIChatWidget />
    </div>
  );
};

export default PatronDashboard;
