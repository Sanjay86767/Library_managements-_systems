import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";

const Register = () => {
  const { register } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", phone: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      await register(form);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    } finally {
      setBusy(false);
    }
  };

  const fieldLabel = { name: t("name"), email: t("email"), phone: t("phone") };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-parchment px-6">
      <form onSubmit={submit} className="bg-white/70 border border-brass/30 rounded-sm p-8 w-full max-w-sm">
        <p className="catalog-label text-xs text-burgundy mb-2">{t("newMembership")}</p>
        <h1 className="font-display text-3xl text-ink mb-6">{t("joinLibrary")}</h1>
        {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}
        {["name", "email", "phone"].map((field) => (
          <div key={field} className="mb-4">
            <label className="font-ui text-xs text-ink/60 block mb-1">{fieldLabel[field]}</label>
            <input
              required={field !== "phone"}
              type={field === "email" ? "email" : "text"}
              value={form[field]}
              onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              className="w-full px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
            />
          </div>
        ))}
        <label className="font-ui text-xs text-ink/60 block mb-1">{t("password")}</label>
        <input required type="password" minLength={6} value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full mb-6 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
        <button disabled={busy} className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50">
          {busy ? t("creatingCard") : t("createMyCard")}
        </button>
        <p className="font-ui text-xs text-ink/60 mt-4 text-center">
          {t("alreadyMember")} <Link to="/login" className="text-burgundy underline">{t("signIn")}</Link>
        </p>
      </form>
    </div>
  );
};

export default Register;
