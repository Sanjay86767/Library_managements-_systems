import React, { useEffect, useState } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell,
} from "recharts";
import api from "../api/axios.js";
import ChangePasswordForm from "../components/ChangePasswordForm.jsx";
import TwoFactorSetup from "../components/TwoFactorSetup.jsx";
import AuditLogViewer from "../components/AuditLogViewer.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const emptyBook = { title: "", author: "", isbn: "", genre: "", quantity: 1, publishedYear: "", publisher: "", shelfLocation: "" };
const PIE_COLORS = ["#7A2E2E", "#16233D", "#6B8F71", "#B08D57", "#B5473A", "#5E2222"];
const KANBAN_COLUMNS = [
  { key: "issued", label: "Issued" },
  { key: "overdue", label: "Overdue" },
  { key: "returned", label: "Returned" },
];

const AdminDashboard = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [tab, setTab] = useState("overview");
  const [stats, setStats] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [books, setBooks] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [form, setForm] = useState(emptyBook);
  const [editingId, setEditingId] = useState(null);
  const [msg, setMsg] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [dragOverCol, setDragOverCol] = useState(null);

  const loadAll = async () => {
    const [s, b, t] = await Promise.all([
      api.get("/books/stats/overview"),
      api.get("/books", { params: { limit: 50 } }),
      api.get("/transactions", { params: { limit: 50 } }),
    ]);
    setStats(s.data);
    setBooks(b.data.books);
    setTransactions(t.data.transactions);
  };

  const loadAnalytics = async () => {
    const { data } = await api.get("/analytics/overview");
    setAnalytics(data);
  };

  useEffect(() => { loadAll(); }, []);
  useEffect(() => { if (tab === "analytics" && !analytics) loadAnalytics(); }, [tab]);

  const submitBook = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.put(`/books/${editingId}`, form);
        setMsg("Book updated.");
      } else {
        await api.post("/books", form);
        setMsg("Book added to catalog.");
      }
      setForm(emptyBook); setEditingId(null);
      loadAll();
    } catch (err) { setMsg(err.response?.data?.message || "Save failed"); }
  };

  const editBook = (b) => {
    setEditingId(b._id);
    setForm({ title: b.title, author: b.author, isbn: b.isbn, genre: b.genre, quantity: b.quantity, publishedYear: b.publishedYear || "", publisher: b.publisher || "", shelfLocation: b.shelfLocation || "" });
    setTab("inventory");
  };

  const removeBook = async (id) => {
    await api.delete(`/books/${id}`);
    loadAll();
  };

  const markReturned = async (id) => {
    setBusyId(id);
    try { await api.put(`/transactions/${id}/return`); loadAll(); }
    finally { setBusyId(null); }
  };

  // Effective column for a transaction: an "issued" loan whose due date has
  // passed displays under Overdue even though its DB status is still
  // "issued" until the librarian explicitly returns it.
  const columnFor = (t) => {
    if (t.status === "returned") return "returned";
    if (t.status === "overdue") return "overdue";
    return new Date(t.dueDate) < new Date() ? "overdue" : "issued";
  };

  const onDrop = (colKey) => (e) => {
    e.preventDefault();
    setDragOverCol(null);
    const id = e.dataTransfer.getData("text/transaction-id");
    const t = transactions.find((x) => x._id === id);
    if (!t || t.status === "returned") return;
    if (colKey === "returned") markReturned(id);
    // Dragging into Issued/Overdue is a no-op — those states are derived
    // from due date, not something a librarian sets directly.
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <p className="catalog-label text-xs text-burgundy mb-1">{t("librarianDesk")}</p>
      <h1 className="font-display text-4xl text-ink mb-8">{t("circulationControl")}</h1>

      <div className="flex gap-3 mb-8 font-ui text-sm flex-wrap">
        {["overview", "analytics", "inventory", "circulation", ...(user.role === "admin" ? ["audit"] : []), "account"].map((tb) => (
          <button key={tb} onClick={() => setTab(tb)}
            className={`px-4 py-2 rounded-sm capitalize transition-colors ${tab === tb ? "bg-ink text-parchment" : "bg-white/60 text-ink border border-brass/30"}`}>
            {tb === "audit" ? "Audit Logs" : t(tb)}
          </button>
        ))}
      </div>

      {msg && <div className="mb-6 font-ui text-sm bg-brass/15 border border-brass/40 px-4 py-3 rounded-sm">{msg}</div>}

      {tab === "overview" && stats && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 grid grid-cols-2 gap-4 content-start">
            {[
              ["Titles", stats.totalTitles],
              ["Total copies", stats.totalCopies],
              ["On shelf", stats.totalAvailable],
              ["Checked out", stats.totalIssued],
            ].map(([label, val]) => (
              <div key={label} className="bg-white/60 border border-brass/30 rounded-sm p-4">
                <p className="font-display text-3xl text-burgundy">{val}</p>
                <p className="catalog-label text-[10px] text-ink/60 mt-1">{label}</p>
              </div>
            ))}
          </div>
          <div className="lg:col-span-2 bg-white/60 border border-brass/30 rounded-sm p-4">
            <p className="font-ui text-sm text-ink/70 mb-2">Titles by genre</p>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={stats.byGenre.map((g) => ({ genre: g._id, count: g.count }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#B08D5733" />
                <XAxis dataKey="genre" tick={{ fontSize: 11, fontFamily: "Inter" }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#7A2E2E" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {tab === "analytics" && (
        !analytics ? <p className="font-ui text-ink/50">Loading analytics…</p> : (
          <div className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-4">
              <div className="bg-white/60 border border-brass/30 rounded-sm p-4 text-center">
                <p className="font-display text-3xl text-burgundy">₹{analytics.fines.total}</p>
                <p className="catalog-label text-[10px] text-ink/60 mt-1">Total fines levied</p>
              </div>
              <div className="bg-white/60 border border-brass/30 rounded-sm p-4 text-center">
                <p className="font-display text-3xl text-sage">₹{analytics.fines.paid}</p>
                <p className="catalog-label text-[10px] text-ink/60 mt-1">Fines collected</p>
              </div>
              <div className="bg-white/60 border border-brass/30 rounded-sm p-4 text-center">
                <p className="font-display text-3xl text-rust">₹{analytics.fines.outstanding}</p>
                <p className="catalog-label text-[10px] text-ink/60 mt-1">Outstanding</p>
              </div>
            </div>

            <div className="bg-white/60 border border-brass/30 rounded-sm p-4">
              <p className="font-ui text-sm text-ink/70 mb-2">Issued vs. returned (last 6 months)</p>
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={analytics.trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#B08D5733" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fontFamily: "Inter" }} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12, fontFamily: "Inter" }} />
                  <Line type="monotone" dataKey="issued" stroke="#7A2E2E" strokeWidth={2} />
                  <Line type="monotone" dataKey="returned" stroke="#6B8F71" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <div className="bg-white/60 border border-brass/30 rounded-sm p-4">
                <p className="font-ui text-sm text-ink/70 mb-2">Catalog composition</p>
                <ResponsiveContainer width="100%" height={240}>
                  <PieChart>
                    <Pie data={analytics.byGenre.map((g) => ({ name: g._id, value: g.count }))}
                      dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}
                      label={({ name }) => name}>
                      {analytics.byGenre.map((g, i) => <Cell key={g._id} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white/60 border border-brass/30 rounded-sm p-4">
                <p className="font-ui text-sm text-ink/70 mb-3">Top borrowers</p>
                <div className="space-y-2">
                  {analytics.topBorrowers.map((b, i) => (
                    <div key={b.membershipId} className="flex items-center justify-between font-ui text-sm">
                      <span className="text-ink">#{i + 1} {b.name} <span className="text-ink/40 text-xs">({b.membershipId})</span></span>
                      <span className="text-ink/60">{b.loanCount} loans</span>
                    </div>
                  ))}
                  {analytics.topBorrowers.length === 0 && <p className="font-ui text-sm text-ink/40">No loans yet.</p>}
                </div>
              </div>
            </div>

            <div className="bg-white/60 border border-brass/30 rounded-sm p-4">
              <p className="font-ui text-sm text-ink/70 mb-3">Top-rated titles ({analytics.reviewCount} reviews total)</p>
              <div className="space-y-2">
                {analytics.topRated.map((b) => (
                  <div key={b._id} className="flex items-center justify-between font-ui text-sm">
                    <span className="text-ink">{b.title} <span className="text-ink/40 text-xs">by {b.author}</span></span>
                    <span className="text-brass">{"★".repeat(Math.round(b.rating))} ({b.reviewCount})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )
      )}

      {tab === "inventory" && (
        <div className="grid lg:grid-cols-3 gap-8">
          <form onSubmit={submitBook} className="lg:col-span-1 bg-white/60 border border-brass/30 rounded-sm p-5 h-fit">
            <h3 className="font-display text-xl text-ink mb-4">{editingId ? "Edit title" : "Add a new title"}</h3>
            {["title", "author", "isbn", "genre", "publisher", "shelfLocation"].map((f) => (
              <input key={f} required={["title","author","isbn"].includes(f)} placeholder={f}
                value={form[f]} onChange={(e) => setForm({ ...form, [f]: e.target.value })}
                className="w-full mb-3 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass capitalize" />
            ))}
            <input type="number" min={0} placeholder="quantity" value={form.quantity}
              onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
              className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
            <div className="flex gap-2">
              <button className="flex-1 bg-burgundy text-white font-ui text-sm py-2 rounded-sm">{editingId ? "Save changes" : "Add title"}</button>
              {editingId && <button type="button" onClick={() => { setEditingId(null); setForm(emptyBook); }} className="px-3 py-2 font-ui text-sm border border-brass/40 rounded-sm">Cancel</button>}
            </div>
          </form>

          <div className="lg:col-span-2 space-y-2">
            {books.map((b) => (
              <div key={b._id} className="bg-white/60 border border-brass/30 rounded-sm p-3 flex items-center justify-between flex-wrap gap-2">
                <div>
                  <p className="font-display text-ink">{b.title}</p>
                  <p className="font-ui text-xs text-ink/60">{b.author} · {b.available}/{b.quantity} available · ISBN {b.isbn}</p>
                </div>
                <div className="flex gap-2 font-ui text-xs">
                  <button onClick={() => editBook(b)} className="px-3 py-1.5 border border-brass/40 rounded-sm">Edit</button>
                  <button onClick={() => removeBook(b._id)} className="px-3 py-1.5 border border-rust/40 text-rust rounded-sm">Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "circulation" && (
        <div>
          <p className="font-ui text-xs text-ink/50 mb-4">Drag a card into "Returned" to check a book back in.</p>
          <div className="grid sm:grid-cols-3 gap-4">
            {KANBAN_COLUMNS.map((col) => (
              <div key={col.key}
                onDragOver={(e) => { e.preventDefault(); setDragOverCol(col.key); }}
                onDragLeave={() => setDragOverCol((c) => (c === col.key ? null : c))}
                onDrop={onDrop(col.key)}
                className={`kanban-column bg-white/40 border border-brass/30 rounded-sm p-3 min-h-[200px] ${dragOverCol === col.key ? "drag-over" : ""}`}>
                <p className="catalog-label text-[10px] text-burgundy mb-3">{col.label} ({transactions.filter((tx) => columnFor(tx) === col.key).length})</p>
                <div className="space-y-2">
                  {transactions.filter((tx) => columnFor(tx) === col.key).map((tx) => (
                    <div key={tx._id}
                      draggable={tx.status !== "returned"}
                      onDragStart={(e) => e.dataTransfer.setData("text/transaction-id", tx._id)}
                      className="kanban-card bg-white border border-brass/20 rounded-sm p-3 shadow-sm">
                      <p className="font-display text-sm text-ink">{tx.book?.title}</p>
                      <p className="font-ui text-[11px] text-ink/60">{tx.user?.name} ({tx.user?.membershipId})</p>
                      <p className="font-ui text-[10px] text-ink/40">Due {new Date(tx.dueDate).toLocaleDateString()}</p>
                      {col.key !== "returned" && (
                        <button disabled={busyId === tx._id} onClick={() => markReturned(tx._id)}
                          className="mt-2 w-full font-ui text-[11px] bg-sage text-white py-1 rounded-sm disabled:opacity-40">
                          {t("markReturned")}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "account" && (
        <div className="space-y-6">
          <ChangePasswordForm />
          <TwoFactorSetup />
        </div>
      )}

      {tab === "audit" && <AuditLogViewer />}
    </div>
  );
};

export default AdminDashboard;
