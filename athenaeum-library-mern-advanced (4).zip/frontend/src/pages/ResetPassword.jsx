import React, { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const ResetPassword = () => {
  const { token } = useParams();
  const { resetPassword } = useAuth();
  const navigate = useNavigate();

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");

    if (password !== confirm) {
      setError("Passwords don't match");
      return;
    }

    setBusy(true);
    try {
      await resetPassword(token, password);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "This reset link is invalid or has expired");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-parchment px-6">
      <form onSubmit={submit} className="bg-white/70 border border-brass/30 rounded-sm p-8 w-full max-w-sm">
        <p className="catalog-label text-xs text-burgundy mb-2">New key, new lock</p>
        <h1 className="font-display text-3xl text-ink mb-6">Reset password</h1>
        {error && (
          <p className="font-ui text-sm text-rust mb-4">
            {error}{" "}
            {error.toLowerCase().includes("invalid") || error.toLowerCase().includes("expired") ? (
              <Link to="/forgot-password" className="underline">Request a new link</Link>
            ) : null}
          </p>
        )}
        <label className="font-ui text-xs text-ink/60 block mb-1">New password</label>
        <input
          required
          type="password"
          minLength={6}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
        />
        <label className="font-ui text-xs text-ink/60 block mb-1">Confirm password</label>
        <input
          required
          type="password"
          minLength={6}
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          className="w-full mb-6 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
        />
        <button
          disabled={busy}
          className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50"
        >
          {busy ? "Resetting…" : "Reset password"}
        </button>
        <p className="font-ui text-xs text-ink/60 mt-4 text-center">
          <Link to="/login" className="text-burgundy underline">Back to sign in</Link>
        </p>
      </form>
    </div>
  );
};

export default ResetPassword;
