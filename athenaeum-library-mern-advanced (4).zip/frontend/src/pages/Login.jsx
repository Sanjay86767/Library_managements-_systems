import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";

const Login = () => {
  const { login, completeLogin2FA } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  // Two-factor step: once the password checks out on an account with 2FA
  // enabled, the backend hands back a short-lived tempToken instead of a
  // session — we hold onto it just long enough to collect the 6-digit code.
  const [pending2FA, setPending2FA] = useState(null); // { tempToken }
  const [code, setCode] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      const data = await login(form.email, form.password);
      if (data.requires2FA) {
        setPending2FA({ tempToken: data.tempToken });
      } else {
        navigate("/dashboard");
      }
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    } finally {
      setBusy(false);
    }
  };

  const submitCode = async (e) => {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      await completeLogin2FA(pending2FA.tempToken, code);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Verification failed");
    } finally {
      setBusy(false);
    }
  };

  if (pending2FA) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-parchment px-6">
        <form onSubmit={submitCode} className="bg-white/70 border border-brass/30 rounded-sm p-8 w-full max-w-sm">
          <p className="catalog-label text-xs text-burgundy mb-2">Two-factor authentication</p>
          <h1 className="font-display text-3xl text-ink mb-2">Enter your code</h1>
          <p className="font-ui text-xs text-ink/60 mb-6">Open your authenticator app and enter the 6-digit code.</p>
          {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}
          <input required autoFocus maxLength={6} inputMode="numeric" value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
            placeholder="123456"
            className="w-full mb-6 px-3 py-2 tracking-[0.5em] text-center border border-brass/40 rounded-sm bg-parchment font-ui text-lg outline-none focus:border-brass" />
          <button disabled={busy || code.length !== 6} className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50">
            {busy ? "Verifying…" : "Verify & sign in"}
          </button>
          <button type="button" onClick={() => { setPending2FA(null); setCode(""); setError(""); }}
            className="w-full mt-3 font-ui text-xs text-ink/60 underline">
            Back to sign in
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-parchment px-6">
      <form onSubmit={submit} className="bg-white/70 border border-brass/30 rounded-sm p-8 w-full max-w-sm">
        <p className="catalog-label text-xs text-burgundy mb-2">{t("libraryCard")}</p>
        <h1 className="font-display text-3xl text-ink mb-6">{t("signIn")}</h1>
        {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}
        <label className="font-ui text-xs text-ink/60 block mb-1">{t("email")}</label>
        <input required type="email" value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
        <div className="flex items-center justify-between mb-1">
          <label className="font-ui text-xs text-ink/60">{t("password")}</label>
          <Link to="/forgot-password" className="font-ui text-xs text-burgundy underline">
            {t("forgotPassword")}
          </Link>
        </div>
        <input required type="password" value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full mb-6 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
        <button disabled={busy} className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50">
          {busy ? t("signingIn") : t("signIn")}
        </button>
        <p className="font-ui text-xs text-ink/60 mt-4 text-center">
          {t("newHere")} <Link to="/register" className="text-burgundy underline">{t("joinLibraryLink")}</Link>
        </p>
      </form>
    </div>
  );
};

export default Login;
