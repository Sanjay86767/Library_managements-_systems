import React, { useState } from "react";
import api from "../api/axios.js";
import { useAuth } from "../context/AuthContext.jsx";

const FreeLibrary = () => {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [count, setCount] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [msg, setMsg] = useState("");
  const [reader, setReader] = useState(null); // { title, url } while a book is open

  const search = async (e) => {
    e?.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get("/free-books/search", { params: { q: query } });
      setResults(data.results);
      setCount(data.count);
    } catch (err) {
      setError(err.response?.data?.message || "Search failed, please try again");
    } finally {
      setLoading(false);
    }
  };

  const addToWishlist = async (book) => {
    if (!user) return setMsg("Sign in to save books to your wishlist.");
    const readUrl = book.readOnline.html || book.readOnline.plainText;
    try {
      await api.post("/wishlist", {
        freeBook: {
          gutenbergId: book.gutenbergId,
          title: book.title,
          author: book.authors[0] || "Unknown",
          coverUrl: book.coverUrl,
          readUrl,
        },
      });
      setMsg(`"${book.title}" saved to your wishlist.`);
    } catch (err) {
      setMsg(err.response?.data?.message || "Could not save to wishlist");
    }
  };

  const openReader = (book) => {
    const url = book.readOnline.html || book.readOnline.plainText;
    if (!url) {
      setMsg("No online-readable format available for this title — try the epub download instead.");
      return;
    }
    setReader({ title: book.title, url });
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <p className="catalog-label text-xs text-burgundy mb-1">Worldwide · public domain · 100% free</p>
      <h1 className="font-display text-4xl text-ink mb-2">Free World Library</h1>
      <p className="font-ui text-sm text-ink/60 mb-8 max-w-2xl">
        Search over 70,000 public-domain books from Project Gutenberg — anyone, anywhere can read them
        online for free, no borrowing limit and no waiting list.
      </p>

      <form onSubmit={search} className="flex gap-3 mb-8 max-w-lg">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search any title, author, or subject…"
          className="flex-1 px-3 py-2 border border-brass/40 rounded-sm bg-white/70 font-ui text-sm outline-none focus:border-brass"
        />
        <button className="bg-burgundy hover:bg-burgundy2 text-white px-5 py-2 rounded-sm font-ui text-sm transition-colors">
          {loading ? "Searching…" : "Search"}
        </button>
      </form>

      {error && <div className="mb-6 font-ui text-sm bg-rust/10 border border-rust/30 text-rust px-4 py-3 rounded-sm">{error}</div>}
      {msg && <div className="mb-6 font-ui text-sm bg-brass/15 border border-brass/40 px-4 py-3 rounded-sm">{msg}</div>}

      {count !== null && (
        <p className="font-ui text-xs text-ink/50 mb-4">{count.toLocaleString()} matching titles worldwide</p>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {results.map((b) => (
          <div key={b.gutenbergId} className="group bg-white/60 border border-brass/30 rounded-sm overflow-hidden hover:shadow-xl transition-all duration-300">
            <div className="h-48 bg-ink/5 flex items-center justify-center overflow-hidden">
              {b.coverUrl ? (
                <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
              ) : (
                <p className="font-display text-ink/40 text-center px-4">{b.title}</p>
              )}
            </div>
            <div className="p-4">
              <h3 className="font-display text-ink text-base leading-snug line-clamp-2">{b.title}</h3>
              <p className="font-ui text-xs text-ink/60 mt-1 line-clamp-1">
                {b.authors.length ? `by ${b.authors.join(", ")}` : "Unknown author"}
              </p>
              <div className="flex items-center gap-2 mt-3">
                <button
                  onClick={() => openReader(b)}
                  className="flex-1 font-ui text-xs bg-burgundy text-white px-3 py-1.5 rounded-sm hover:bg-burgundy2 transition-colors"
                >
                  Read free
                </button>
                <button
                  onClick={() => addToWishlist(b)}
                  title="Save to wishlist"
                  className="font-ui text-sm border border-brass/40 px-2.5 py-1.5 rounded-sm hover:bg-brass/10 transition-colors"
                >
                  ♡
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {results.length === 0 && !loading && count === null && (
        <div className="font-ui text-ink/60 bg-white/50 border border-brass/30 rounded-sm p-10 text-center">
          Try searching for an author or title — e.g. "Jane Austen", "Sherlock Holmes", "Shakespeare".
        </div>
      )}

      {/* In-page reader */}
      {reader && (
        <div className="fixed inset-0 bg-ink/80 z-50 flex items-center justify-center p-4" onClick={() => setReader(null)}>
          <div
            className="bg-parchment w-full max-w-4xl h-[85vh] rounded-sm overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 bg-ink text-parchment">
              <p className="font-display text-lg truncate pr-4">{reader.title}</p>
              <div className="flex items-center gap-3 shrink-0">
                <a
                  href={reader.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-ui text-xs underline text-brass"
                >
                  Open in new tab
                </a>
                <button onClick={() => setReader(null)} className="font-ui text-sm">✕</button>
              </div>
            </div>
            <iframe title={reader.title} src={reader.url} className="flex-1 w-full bg-white" />
          </div>
        </div>
      )}
    </div>
  );
};

export default FreeLibrary;
