import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios.js";
import BookCard from "../components/BookCard.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const SHELF_BOOKS = [
  { title: "Fiction", color: "#7A2E2E", h: 210 },
  { title: "Science", color: "#3E5A50", h: 240 },
  { title: "History", color: "#16233D", h: 195 },
  { title: "Poetry", color: "#B08D57", h: 225 },
  { title: "Biography", color: "#5E2222", h: 205 },
  { title: "Mystery", color: "#6B8F71", h: 235 },
  { title: "Philosophy", color: "#8A6A3F", h: 215 },
];

const Landing = () => {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("all");
  const [genres, setGenres] = useState([]);
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [borrowingId, setBorrowingId] = useState(null);
  const [msg, setMsg] = useState("");

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/books", { params: { search: query, genre, limit: 8 } });
      setBooks(data.books);
      setGenres(data.genres || []);
    } catch (e) {
      // Fails silently if backend isn't running yet - demo mode
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
    api.get("/books/stats/overview").then((r) => setStats(r.data)).catch(() => {});
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchBooks();
  };

  const handleBorrow = async (book) => {
    if (!user) return setMsg("Sign in to borrow a book.");
    setBorrowingId(book._id);
    try {
      await api.post("/transactions/issue", { bookId: book._id });
      setMsg(`"${book.title}" issued — due in 14 days.`);
      fetchBooks();
    } catch (err) {
      setMsg(err.response?.data?.message || "Could not issue this book.");
    } finally {
      setBorrowingId(null);
    }
  };

  return (
    <div className="bg-parchment min-h-screen">
      {/* HERO — the card-catalog / shelf signature */}
      <section className="relative overflow-hidden bg-ink text-parchment">
        <div className="max-w-7xl mx-auto px-6 pt-16 pb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="catalog-label text-brass text-xs mb-4">Est. in code · MERN Stack Athenaeum</p>
            <h1 className="font-display text-5xl md:text-6xl leading-[1.05] mb-6">
              Every book,
              <br /> one <span className="text-brass italic">ledger</span> away.
            </h1>
            <p className="font-body text-parchment/75 text-lg max-w-md mb-8">
              Browse the full catalog, borrow with a click, and let the system track your
              due dates and fines automatically — built for patrons and librarians alike.
            </p>
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3 max-w-lg">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search title, author, or genre…"
                className="flex-1 bg-parchment text-ink font-ui text-sm px-4 py-3 rounded-sm outline-none border-2 border-transparent focus:border-brass"
              />
              <button className="bg-burgundy hover:bg-burgundy2 transition-colors font-ui text-sm px-6 py-3 rounded-sm">
                Search catalog
              </button>
            </form>
            {stats && (
              <div className="flex gap-8 mt-10 font-ui">
                <div>
                  <p className="text-3xl font-display text-brass">{stats.totalTitles}</p>
                  <p className="text-xs text-parchment/60 catalog-label">Titles</p>
                </div>
                <div>
                  <p className="text-3xl font-display text-brass">{stats.totalAvailable}</p>
                  <p className="text-xs text-parchment/60 catalog-label">On the shelf</p>
                </div>
                <div>
                  <p className="text-3xl font-display text-brass">{stats.totalIssued}</p>
                  <p className="text-xs text-parchment/60 catalog-label">Checked out</p>
                </div>
              </div>
            )}
          </div>

          {/* Animated bookshelf signature element */}
          <div className="shelf flex items-end justify-center gap-2 h-72 relative">
            {SHELF_BOOKS.map((b, i) => (
              <div
                key={i}
                className="spine flex items-end justify-center rounded-t-sm cursor-default"
                style={{ background: b.color, width: 42, height: b.h }}
              >
                <span className="spine-title font-display text-parchment/90 text-xs py-3 whitespace-nowrap">
                  {b.title}
                </span>
              </div>
            ))}
            <div className="absolute -bottom-2 left-0 right-0 h-3 bg-brass rounded-sm" />
          </div>
        </div>
      </section>

      {/* Feature strip */}
      <section className="max-w-7xl mx-auto px-6 py-14 grid sm:grid-cols-3 gap-6">
        {[
          { t: "Real-time availability", d: "Copy counts update the instant a book is issued or returned." },
          { t: "Automatic fines", d: "Overdue fines calculate themselves — no manual math for the desk." },
          { t: "Role-based desks", d: "Patrons browse and borrow; librarians manage inventory and loans." },
        ].map((f, i) => (
          <div key={i} className="border-l-2 border-brass pl-4">
            <p className="catalog-label text-xs text-burgundy mb-1">{String(i + 1).padStart(2, "0")}</p>
            <h3 className="font-display text-xl text-ink mb-1">{f.t}</h3>
            <p className="font-body text-sm text-ink/60">{f.d}</p>
          </div>
        ))}
      </section>

      {/* Live catalog */}
      <section className="max-w-7xl mx-auto px-6 pb-20">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <h2 className="font-display text-3xl text-ink">From the stacks</h2>
          <select
            value={genre}
            onChange={(e) => { setGenre(e.target.value); }}
            className="font-ui text-sm border border-brass/40 bg-white/70 rounded-sm px-3 py-2"
          >
            <option value="all">All genres</option>
            {genres.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>

        {msg && (
          <div className="mb-6 font-ui text-sm bg-brass/15 border border-brass/40 text-ink px-4 py-3 rounded-sm">
            {msg}
          </div>
        )}

        {loading ? (
          <p className="font-ui text-ink/50">Loading catalog…</p>
        ) : books.length === 0 ? (
          <div className="font-ui text-ink/60 bg-white/50 border border-brass/30 rounded-sm p-8 text-center">
            No books indexed yet. Connect the backend and add titles from the librarian desk to populate the catalog.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {books.map((b) => (
              <BookCard key={b._id} book={b} onBorrow={handleBorrow} borrowing={borrowingId === b._id} />
            ))}
          </div>
        )}

        {!user && (
          <div className="mt-10 text-center">
            <Link to="/register" className="font-ui text-sm bg-ink text-parchment px-6 py-3 rounded-sm hover:bg-ink/90 transition-colors inline-block">
              Join the library to start borrowing
            </Link>
          </div>
        )}
      </section>
    </div>
  );
};

export default Landing;
