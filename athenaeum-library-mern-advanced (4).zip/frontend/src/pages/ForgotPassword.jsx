import React, { useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios.js";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await api.post("/auth/forgot-password", { email });
      // Backend always returns a generic message, sent or not, so a stranger
      // can't use this form to probe which emails have accounts.
      setSent(true);
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong, please try again");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-parchment px-6">
      <div className="bg-white/70 border border-brass/30 rounded-sm p-8 w-full max-w-sm">
        <p className="catalog-label text-xs text-burgundy mb-2">Lost your card</p>
        <h1 className="font-display text-3xl text-ink mb-6">Forgot password</h1>

        {sent ? (
          <div>
            <p className="font-ui text-sm text-ink/80 mb-6">
              If an account exists for <span className="text-ink font-medium">{email}</span>,
              we've sent a reset link to it. Check your inbox — the link expires in 30 minutes.
            </p>
            <Link
              to="/login"
              className="block text-center w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors"
            >
              Back to sign in
            </Link>
          </div>
        ) : (
          <form onSubmit={submit}>
            <p className="font-ui text-sm text-ink/70 mb-6">
              Enter the email on your library account and we'll send you a link to reset your password.
            </p>
            {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}
            <label className="font-ui text-xs text-ink/60 block mb-1">Email</label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full mb-6 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
            />
            <button
              disabled={busy}
              className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50"
            >
              {busy ? "Sending…" : "Send reset link"}
            </button>
            <p className="font-ui text-xs text-ink/60 mt-4 text-center">
              Remembered it? <Link to="/login" className="text-burgundy underline">Sign in</Link>
            </p>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPassword;
