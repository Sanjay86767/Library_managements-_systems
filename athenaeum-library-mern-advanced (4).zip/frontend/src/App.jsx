import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import ResetPassword from "./pages/ResetPassword.jsx";
import FreeLibrary from "./pages/FreeLibrary.jsx";
import BookDetail from "./pages/BookDetail.jsx";
import PatronDashboard from "./pages/PatronDashboard.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import { useAuth } from "./context/AuthContext.jsx";

const DashboardRouter = () => {
  const { user } = useAuth();
  if (!user) return null;
  return ["admin", "librarian"].includes(user.role) ? <AdminDashboard /> : <PatronDashboard />;
};

function App() {
  return (
    <div className="min-h-screen bg-parchment font-body">
      <Navbar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />
        <Route path="/free-library" element={<FreeLibrary />} />
        <Route path="/books/:id" element={<BookDetail />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardRouter />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
