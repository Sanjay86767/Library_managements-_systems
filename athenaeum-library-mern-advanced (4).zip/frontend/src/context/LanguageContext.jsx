import React, { createContext, useContext, useState } from "react";
import { translations } from "../i18n/translations.js";

const LanguageContext = createContext(null);

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState(() => localStorage.getItem("athenaeum_lang") || "en");

  const setLanguage = (l) => {
    setLang(l);
    localStorage.setItem("athenaeum_lang", l);
  };
  const toggleLanguage = () => setLanguage(lang === "en" ? "hi" : "en");

  // Falls back to the key itself if a translation is missing, so partially
  // translated screens never show a blank or [object] string.
  const t = (key) => translations[lang]?.[key] ?? translations.en[key] ?? key;

  return (
    <LanguageContext.Provider value={{ lang, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
