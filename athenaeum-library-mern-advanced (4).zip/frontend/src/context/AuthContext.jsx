import React, { createContext, useContext, useState, useEffect } from "react";
import api from "../api/axios.js";
import { disconnectSocket } from "../socket.js";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("athenaeum_token");
    const cached = localStorage.getItem("athenaeum_user");
    if (token && cached) setUser(JSON.parse(cached));
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    // A 2FA-enabled account returns a short-lived tempToken instead of a
    // real session — the caller (Login page) must collect the 6-digit
    // code and call completeLogin2FA() before anything gets persisted.
    if (data.requires2FA) return data;
    persist(data);
    return data;
  };

  const completeLogin2FA = async (tempToken, token) => {
    const { data } = await api.post("/auth/2fa/login-verify", { tempToken, token });
    persist(data);
    return data;
  };

  const register = async (payload) => {
    const { data } = await api.post("/auth/register", payload);
    persist(data);
    return data;
  };

  const persist = (data) => {
    const { token, ...userData } = data;
    localStorage.setItem("athenaeum_token", token);
    localStorage.setItem("athenaeum_user", JSON.stringify(userData));
    setUser(userData);
  };

  // Reset link sets a fresh password and logs the user straight in, same as
  // login/register do — the backend returns a token either way.
  const resetPassword = async (token, password) => {
    const { data } = await api.put(`/auth/reset-password/${token}`, { password });
    persist(data);
    return data;
  };

  const logout = () => {
    localStorage.removeItem("athenaeum_token");
    localStorage.removeItem("athenaeum_user");
    disconnectSocket();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, completeLogin2FA, register, logout, loading, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
