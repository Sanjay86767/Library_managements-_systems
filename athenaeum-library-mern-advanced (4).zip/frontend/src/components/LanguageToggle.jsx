import React from "react";
import { useLanguage } from "../context/LanguageContext.jsx";

const LanguageToggle = () => {
  const { lang, toggleLanguage } = useLanguage();
  return (
    <button
      onClick={toggleLanguage}
      aria-label="Toggle language"
      title={lang === "en" ? "हिंदी में बदलें" : "Switch to English"}
      className="w-9 h-8 flex items-center justify-center rounded-sm border border-brass/40 hover:border-brass transition-colors font-ui text-xs"
    >
      {lang === "en" ? "हिं" : "EN"}
    </button>
  );
};

export default LanguageToggle;
