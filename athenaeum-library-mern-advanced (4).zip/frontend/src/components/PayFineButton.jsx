import React, { useState } from "react";
import api from "../api/axios.js";

// Loads the Razorpay checkout script on demand rather than in index.html,
// so pages that never touch payments don't pay for it.
const loadRazorpayScript = () =>
  new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });

const PayFineButton = ({ transactionId, amount, patronName, patronEmail, onPaid }) => {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const pay = async () => {
    setBusy(true);
    setError("");
    try {
      const loaded = await loadRazorpayScript();
      if (!loaded) throw new Error("Could not load payment gateway — check your connection.");

      const { data } = await api.post(`/payments/fine/${transactionId}/order`);
      const rzp = new window.Razorpay({
        key: data.keyId,
        amount: data.order.amount,
        currency: data.order.currency,
        name: "Athenaeum Library",
        description: "Overdue fine payment",
        order_id: data.order.id,
        prefill: { name: patronName, email: patronEmail },
        theme: { color: "#7A2E2E" },
        handler: async (response) => {
          await api.post(`/payments/fine/${transactionId}/verify`, response);
          onPaid?.();
        },
      });
      rzp.on("payment.failed", () => setError("Payment failed — please try again."));
      rzp.open();
    } catch (err) {
      setError(err.response?.data?.message || err.message || "Could not start payment");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="inline-flex flex-col items-end">
      <button onClick={pay} disabled={busy}
        className="font-ui text-xs bg-sage text-white px-3 py-1.5 rounded-sm disabled:opacity-40">
        {busy ? "Starting…" : `Pay ₹${amount} online`}
      </button>
      {error && <p className="font-ui text-[10px] text-rust mt-1">{error}</p>}
    </div>
  );
};

export default PayFineButton;
