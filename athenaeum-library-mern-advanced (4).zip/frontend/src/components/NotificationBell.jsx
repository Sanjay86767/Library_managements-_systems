import React, { useEffect, useRef, useState } from "react";
import api from "../api/axios.js";
import { getSocket } from "../socket.js";

const timeAgo = (date) => {
  const diffMin = Math.floor((Date.now() - new Date(date)) / 60000);
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.floor(diffHr / 24)}d ago`;
};

const NotificationBell = () => {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const boxRef = useRef(null);

  const fetchNotifications = async () => {
    try {
      const { data } = await api.get("/notifications/mine");
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch {
      // Fails quietly — the bell just stays at its last known state
    }
  };

  useEffect(() => {
    fetchNotifications();
    // Polling stays as a safety net; the socket below makes updates land
    // immediately instead of waiting for the next 60s tick.
    const interval = setInterval(fetchNotifications, 60000);

    const socket = getSocket();
    socket?.on("notification:new", fetchNotifications);

    return () => {
      clearInterval(interval);
      socket?.off("notification:new", fetchNotifications);
    };
  }, []);

  useEffect(() => {
    const onClickOutside = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const markRead = async (id) => {
    await api.put(`/notifications/${id}/read`);
    fetchNotifications();
  };

  const markAllRead = async () => {
    await api.put("/notifications/read-all");
    fetchNotifications();
  };

  return (
    <div className="relative" ref={boxRef}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative font-ui text-sm hover:text-brass transition-colors"
        aria-label="Notifications"
      >
        🔔
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-2 bg-rust text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-3 w-80 bg-white text-ink border border-brass/30 rounded-sm shadow-xl z-50 max-h-96 overflow-y-auto">
          <div className="flex items-center justify-between px-4 py-3 border-b border-brass/20">
            <p className="font-ui text-xs catalog-label text-burgundy">Notifications</p>
            {unreadCount > 0 && (
              <button onClick={markAllRead} className="font-ui text-[11px] text-burgundy underline">
                Mark all read
              </button>
            )}
          </div>
          {notifications.length === 0 ? (
            <p className="font-ui text-sm text-ink/50 px-4 py-6 text-center">You're all caught up.</p>
          ) : (
            notifications.map((n) => (
              <button
                key={n._id}
                onClick={() => !n.read && markRead(n._id)}
                className={`w-full text-left px-4 py-3 border-b border-brass/10 last:border-0 hover:bg-parchment/60 transition-colors ${
                  n.read ? "" : "bg-brass/10"
                }`}
              >
                <p className="font-ui text-sm text-ink">{n.title}</p>
                <p className="font-ui text-xs text-ink/60 mt-0.5">{n.message}</p>
                <p className="font-ui text-[10px] text-ink/40 mt-1">{timeAgo(n.createdAt)}</p>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationBell;
