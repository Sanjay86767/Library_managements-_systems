import React from "react";

// A lightweight, dependency-free "virtual shelf": no three.js, just tilted
// CSS spines on a wooden shelf strip, grouped by genre. Full 3D (rotatable
// camera, textures) would need a separate three.js view — this gives most
// of the visual/interactive payoff without that build-size cost.
const SPINE_COLORS = ["#7A2E2E", "#16233D", "#6B8F71", "#B08D57", "#5E2222", "#B5473A"];

const BookshelfView = ({ books, onSelect }) => {
  const byGenre = books.reduce((acc, b) => {
    const g = b.genre || "General";
    (acc[g] = acc[g] || []).push(b);
    return acc;
  }, {});

  return (
    <div className="space-y-10">
      {Object.entries(byGenre).map(([genre, list]) => (
        <div key={genre}>
          <p className="catalog-label text-xs text-burgundy mb-2">{genre}</p>
          <div className="wood-shelf flex items-end gap-1.5 px-4 pt-6 pb-2 overflow-x-auto">
            {list.map((b, i) => (
              <button
                key={b._id}
                onClick={() => onSelect?.(b)}
                title={`${b.title} — ${b.author}`}
                className="shelf-book shrink-0 rounded-sm text-parchment flex items-end justify-center pb-2 font-ui text-[10px] text-center px-1"
                style={{
                  backgroundColor: SPINE_COLORS[i % SPINE_COLORS.length],
                  width: 34 + (i % 3) * 6,
                  height: 150 + (i % 4) * 14,
                  writingMode: "vertical-rl",
                  textOrientation: "mixed",
                }}
              >
                {b.title}
              </button>
            ))}
          </div>
        </div>
      ))}
      {books.length === 0 && <p className="font-ui text-ink/50">No books to shelve yet — try a different search.</p>}
    </div>
  );
};

export default BookshelfView;
