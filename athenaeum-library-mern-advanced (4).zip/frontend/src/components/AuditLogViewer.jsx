import React, { useEffect, useState } from "react";
import api from "../api/axios.js";

const ACTION_COLORS = {
  login_failed: "text-rust",
  login_failed_unknown_email: "text-rust",
  login_blocked_locked: "text-rust",
  login_2fa_failed: "text-rust",
  book_deleted: "text-rust",
  login_success: "text-sage",
  login_2fa_success: "text-sage",
  fine_paid: "text-sage",
  "2fa_enabled": "text-sage",
};

const AuditLogViewer = () => {
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [action, setAction] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await api.get("/audit-logs", { params: { page, limit: 25, action: action || undefined } });
    setData(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, [page, action]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <p className="font-ui text-sm text-ink/60">Security-sensitive events across the whole system.</p>
        <select value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }}
          className="font-ui text-sm border border-brass/40 bg-white/70 rounded-sm px-3 py-2">
          <option value="">All actions</option>
          {data?.actions.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>

      {loading && <p className="font-ui text-ink/50">Loading…</p>}

      {!loading && data && (
        <>
          <div className="overflow-x-auto bg-white/60 border border-brass/30 rounded-sm">
            <table className="w-full font-ui text-xs">
              <thead>
                <tr className="text-left text-ink/50 border-b border-brass/20">
                  <th className="px-3 py-2">When</th>
                  <th className="px-3 py-2">Action</th>
                  <th className="px-3 py-2">User</th>
                  <th className="px-3 py-2">IP</th>
                </tr>
              </thead>
              <tbody>
                {data.logs.map((log) => (
                  <tr key={log._id} className="border-b border-brass/10">
                    <td className="px-3 py-2 whitespace-nowrap text-ink/60">{new Date(log.createdAt).toLocaleString()}</td>
                    <td className={`px-3 py-2 font-medium ${ACTION_COLORS[log.action] || "text-ink"}`}>{log.action}</td>
                    <td className="px-3 py-2 text-ink/70">{log.user?.name || log.email || "—"}</td>
                    <td className="px-3 py-2 text-ink/40">{log.ip || "—"}</td>
                  </tr>
                ))}
                {data.logs.length === 0 && (
                  <tr><td colSpan={4} className="px-3 py-6 text-center text-ink/40">No log entries match this filter.</td></tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between mt-3 font-ui text-xs text-ink/60">
            <span>Page {data.page} of {Math.max(1, data.pages)} · {data.total} total</span>
            <div className="flex gap-2">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1.5 border border-brass/40 rounded-sm disabled:opacity-40">Prev</button>
              <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1.5 border border-brass/40 rounded-sm disabled:opacity-40">Next</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AuditLogViewer;
