import React, { useState } from "react";
import api from "../api/axios.js";
import { useAuth } from "../context/AuthContext.jsx";

const TwoFactorSetup = () => {
  const { user } = useAuth();
  const [step, setStep] = useState("idle"); // idle | scanning | disabling
  const [qrCode, setQrCode] = useState(null);
  const [secret, setSecret] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [enabled, setEnabled] = useState(user.twoFactorEnabled);

  const startSetup = async () => {
    setError(""); setBusy(true);
    try {
      const { data } = await api.post("/auth/2fa/setup");
      setQrCode(data.qrCode);
      setSecret(data.secret);
      setStep("scanning");
    } catch (err) { setError(err.response?.data?.message || "Could not start setup"); }
    finally { setBusy(false); }
  };

  const confirmSetup = async (e) => {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      await api.post("/auth/2fa/verify-setup", { token: code });
      setEnabled(true);
      setStep("idle");
      setCode("");
      setMsg("Two-factor authentication is now enabled on your account.");
    } catch (err) { setError(err.response?.data?.message || "Verification failed"); }
    finally { setBusy(false); }
  };

  const disable = async (e) => {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      await api.post("/auth/2fa/disable", { password });
      setEnabled(false);
      setStep("idle");
      setPassword("");
      setMsg("Two-factor authentication has been disabled.");
    } catch (err) { setError(err.response?.data?.message || "Could not disable 2FA"); }
    finally { setBusy(false); }
  };

  return (
    <div className="bg-white/60 border border-brass/30 rounded-sm p-6 max-w-md">
      <h3 className="font-display text-xl text-ink mb-1">Two-factor authentication</h3>
      <p className="font-ui text-xs text-ink/60 mb-4">
        {enabled ? "Enabled — a 6-digit code from your authenticator app is required at every sign-in." : "Adds a second step at sign-in using an authenticator app (Google Authenticator, Authy, 1Password, etc.)."}
      </p>

      {msg && <p className="font-ui text-sm text-sage mb-4">{msg}</p>}
      {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}

      {step === "idle" && !enabled && (
        <button onClick={startSetup} disabled={busy} className="bg-burgundy text-white font-ui text-sm px-4 py-2 rounded-sm disabled:opacity-50">
          {busy ? "Starting…" : "Enable two-factor authentication"}
        </button>
      )}

      {step === "idle" && enabled && (
        <button onClick={() => setStep("disabling")} className="border border-rust/40 text-rust font-ui text-sm px-4 py-2 rounded-sm">
          Disable two-factor authentication
        </button>
      )}

      {step === "scanning" && qrCode && (
        <form onSubmit={confirmSetup}>
          <p className="font-ui text-xs text-ink/70 mb-3">Scan this QR code with your authenticator app:</p>
          <img src={qrCode} alt="2FA QR code" className="w-40 h-40 mb-3 border border-brass/30 rounded-sm" />
          <p className="font-ui text-[11px] text-ink/50 mb-4 break-all">Can't scan it? Enter this key manually: <span className="text-ink">{secret}</span></p>
          <label className="font-ui text-xs text-ink/60 block mb-1">Enter the 6-digit code to confirm</label>
          <input required maxLength={6} inputMode="numeric" value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
            className="w-full mb-4 px-3 py-2 tracking-[0.4em] text-center border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
          <div className="flex gap-2">
            <button disabled={busy || code.length !== 6} className="bg-burgundy text-white font-ui text-sm px-4 py-2 rounded-sm disabled:opacity-50">
              {busy ? "Confirming…" : "Confirm & enable"}
            </button>
            <button type="button" onClick={() => { setStep("idle"); setQrCode(null); setCode(""); }}
              className="font-ui text-sm px-4 py-2 border border-brass/40 rounded-sm">Cancel</button>
          </div>
        </form>
      )}

      {step === "disabling" && (
        <form onSubmit={disable}>
          <label className="font-ui text-xs text-ink/60 block mb-1">Confirm your password to disable 2FA</label>
          <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
          <div className="flex gap-2">
            <button disabled={busy} className="bg-rust text-white font-ui text-sm px-4 py-2 rounded-sm disabled:opacity-50">
              {busy ? "Disabling…" : "Disable 2FA"}
            </button>
            <button type="button" onClick={() => { setStep("idle"); setPassword(""); }}
              className="font-ui text-sm px-4 py-2 border border-brass/40 rounded-sm">Cancel</button>
          </div>
        </form>
      )}
    </div>
  );
};

export default TwoFactorSetup;
