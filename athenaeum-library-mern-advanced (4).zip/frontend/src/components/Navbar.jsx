import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import NotificationBell from "./NotificationBell.jsx";
import ThemeToggle from "./ThemeToggle.jsx";
import LanguageToggle from "./LanguageToggle.jsx";

const Navbar = () => {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-50 bg-ink text-parchment border-b-2 border-brass/40">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        <Link to="/" className="font-display text-2xl tracking-wide">
          Athen<span className="text-brass">æ</span>um
        </Link>
        <nav className="flex items-center gap-6 font-ui text-sm">
          <Link to="/" className="hover:text-brass transition-colors">{t("catalog")}</Link>
          <Link to="/free-library" className="hover:text-brass transition-colors">{t("freeWorldLibrary")}</Link>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <LanguageToggle />
          </div>
          {user ? (
            <>
              <Link to="/dashboard" className="hover:text-brass transition-colors capitalize">
                {user.role} {t("desk")}
              </Link>
              <NotificationBell />
              <span className="hidden sm:inline text-parchment/60">{t("greeting")}, {user.name.split(" ")[0]}</span>
              <button
                onClick={() => { logout(); navigate("/"); }}
                className="bg-burgundy hover:bg-burgundy2 px-4 py-1.5 rounded-sm transition-colors"
              >
                {t("signOut")}
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-brass transition-colors">{t("signIn")}</Link>
              <Link to="/register" className="bg-burgundy hover:bg-burgundy2 px-4 py-1.5 rounded-sm transition-colors">
                {t("joinLibrary")}
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
