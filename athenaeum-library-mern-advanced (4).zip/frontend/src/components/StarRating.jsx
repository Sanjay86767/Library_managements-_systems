import React from "react";

// Renders 5 stars. Pass `onRate` to make it an interactive input (used in
// the review form); omit it for a read-only display (used on cards).
const StarRating = ({ value = 0, onRate, size = "text-sm", count }) => {
  const stars = [1, 2, 3, 4, 5];
  return (
    <span className="inline-flex items-center gap-0.5">
      {stars.map((n) => (
        <button
          key={n}
          type="button"
          disabled={!onRate}
          onClick={() => onRate && onRate(n)}
          className={`${size} ${onRate ? "cursor-pointer" : "cursor-default"} ${
            n <= Math.round(value) ? "text-brass" : "text-ink/20"
          }`}
        >
          ★
        </button>
      ))}
      {typeof count === "number" && (
        <span className="font-ui text-[11px] text-ink/50 ml-1">
          {value > 0 ? `${value.toFixed(1)} (${count})` : "No reviews yet"}
        </span>
      )}
    </span>
  );
};

export default StarRating;
