import React, { useState } from "react";
import api from "../api/axios.js";

const ChangePasswordForm = () => {
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setMsg("");
    setError("");

    if (form.newPassword !== form.confirm) {
      setError("New passwords don't match");
      return;
    }

    setBusy(true);
    try {
      await api.put("/auth/change-password", {
        currentPassword: form.currentPassword,
        newPassword: form.newPassword,
      });
      setMsg("Password updated successfully.");
      setForm({ currentPassword: "", newPassword: "", confirm: "" });
    } catch (err) {
      setError(err.response?.data?.message || "Could not update password");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="bg-white/60 border border-brass/30 rounded-sm p-6 max-w-sm">
      <h3 className="font-display text-xl text-ink mb-4">Change password</h3>
      {msg && <p className="font-ui text-sm text-sage mb-4">{msg}</p>}
      {error && <p className="font-ui text-sm text-rust mb-4">{error}</p>}

      <label className="font-ui text-xs text-ink/60 block mb-1">Current password</label>
      <input
        required
        type="password"
        value={form.currentPassword}
        onChange={(e) => setForm({ ...form, currentPassword: e.target.value })}
        className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
      />
      <label className="font-ui text-xs text-ink/60 block mb-1">New password</label>
      <input
        required
        type="password"
        minLength={6}
        value={form.newPassword}
        onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
        className="w-full mb-4 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
      />
      <label className="font-ui text-xs text-ink/60 block mb-1">Confirm new password</label>
      <input
        required
        type="password"
        minLength={6}
        value={form.confirm}
        onChange={(e) => setForm({ ...form, confirm: e.target.value })}
        className="w-full mb-6 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass"
      />
      <button
        disabled={busy}
        className="w-full bg-burgundy hover:bg-burgundy2 text-white font-ui text-sm py-2.5 rounded-sm transition-colors disabled:opacity-50"
      >
        {busy ? "Updating…" : "Update password"}
      </button>
    </form>
  );
};

export default ChangePasswordForm;
