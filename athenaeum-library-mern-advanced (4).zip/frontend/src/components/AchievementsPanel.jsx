import React, { useEffect, useState } from "react";
import api from "../api/axios.js";

const AchievementsPanel = () => {
  const [data, setData] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);

  useEffect(() => {
    api.get("/gamification/mine").then((r) => setData(r.data)).catch(() => {});
    api.get("/gamification/leaderboard").then((r) => setLeaderboard(r.data)).catch(() => {});
  }, []);

  if (!data) return <p className="font-ui text-ink/50">Loading your achievements…</p>;

  return (
    <div className="space-y-8">
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="bg-white/60 border border-brass/30 rounded-sm p-5 text-center">
          <p className="font-display text-4xl text-burgundy">{data.points}</p>
          <p className="catalog-label text-[10px] text-ink/60 mt-1">Reading points</p>
        </div>
        <div className="bg-white/60 border border-brass/30 rounded-sm p-5 text-center">
          <p className="font-display text-4xl text-burgundy">🔥 {data.currentStreak}</p>
          <p className="catalog-label text-[10px] text-ink/60 mt-1">Current streak (days)</p>
        </div>
        <div className="bg-white/60 border border-brass/30 rounded-sm p-5 text-center">
          <p className="font-display text-4xl text-burgundy">{data.longestStreak}</p>
          <p className="catalog-label text-[10px] text-ink/60 mt-1">Longest streak</p>
        </div>
      </div>

      <div>
        <p className="font-ui text-sm text-ink/70 mb-3">Badges</p>
        <div className="grid sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {data.badges.map((b) => (
            <div key={b.key}
              className={`border rounded-sm p-4 text-center transition-opacity ${b.earned ? "bg-brass/15 border-brass/50" : "bg-white/40 border-brass/20 opacity-40"}`}>
              <p className="text-2xl mb-1">{b.earned ? "🏅" : "🔒"}</p>
              <p className="font-ui text-xs text-ink">{b.label}</p>
            </div>
          ))}
        </div>
      </div>

      {leaderboard.length > 0 && (
        <div>
          <p className="font-ui text-sm text-ink/70 mb-3">Community leaderboard</p>
          <div className="space-y-2">
            {leaderboard.map((u, i) => (
              <div key={u._id} className="bg-white/60 border border-brass/30 rounded-sm px-4 py-2.5 flex items-center justify-between">
                <span className="font-ui text-sm text-ink">#{i + 1} {u.name}</span>
                <span className="font-ui text-xs text-ink/60">{u.points} pts · 🔥{u.currentStreak}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AchievementsPanel;
