import React from "react";
import { Link } from "react-router-dom";
import StarRating from "./StarRating.jsx";

const SPINE_COLORS = ["#7A2E2E", "#16233D", "#6B8F71", "#B08D57", "#5E2222", "#3E5A50"];

const hashColor = (str = "") => {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h);
  return SPINE_COLORS[Math.abs(h) % SPINE_COLORS.length];
};

const BookCard = ({ book, onBorrow, borrowing, canBorrow = true, onWishlist, wishlisted }) => {
  const color = hashColor(book.title);
  return (
    <div className="group bg-white/60 border border-brass/30 rounded-sm overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
      <Link to={`/books/${book._id}`}>
        <div
          className="h-40 flex items-center justify-center relative"
          style={{ background: `linear-gradient(160deg, ${color}, ${color}CC)` }}
        >
          <span className="catalog-label absolute top-2 left-2 text-[10px] text-white/70">{book.genre}</span>
          {onWishlist && (
            <button
              onClick={(e) => { e.preventDefault(); onWishlist(book); }}
              title="Add to wishlist"
              className={`absolute top-2 right-2 text-lg ${wishlisted ? "text-brass" : "text-white/70"} hover:text-brass transition-colors`}
            >
              {wishlisted ? "♥" : "♡"}
            </button>
          )}
          <p className="font-display text-white text-center px-4 text-lg leading-tight line-clamp-3">
            {book.title}
          </p>
        </div>
      </Link>
      <div className="p-4">
        <Link to={`/books/${book._id}`}>
          <h3 className="font-display text-ink text-base leading-snug line-clamp-2 hover:text-burgundy transition-colors">{book.title}</h3>
        </Link>
        <p className="font-ui text-xs text-ink/60 mt-1">by {book.author}</p>
        {typeof book.rating === "number" && (
          <div className="mt-1.5"><StarRating value={book.rating} count={book.reviewCount} /></div>
        )}
        <div className="flex items-center justify-between mt-3">
          <span
            className={`font-ui text-[11px] px-2 py-0.5 rounded-full ${
              book.available > 0 ? "bg-sage/20 text-sage" : "bg-rust/20 text-rust"
            }`}
          >
            {book.available > 0 ? `${book.available} available` : "All copies out"}
          </span>
          {onBorrow && (
            <button
              disabled={!canBorrow || book.available < 1 || borrowing}
              onClick={() => onBorrow(book)}
              className="font-ui text-xs bg-burgundy text-white px-3 py-1.5 rounded-sm disabled:opacity-40 disabled:cursor-not-allowed hover:bg-burgundy2 transition-colors"
            >
              {borrowing ? "..." : "Borrow"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;
