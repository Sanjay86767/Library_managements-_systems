import React, { useState, useRef, useEffect } from "react";
import api from "../api/axios.js";

const AIChatWidget = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hi! I'm your AI librarian. Ask me for recommendations, genre picks, or what to read next." },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  const send = async (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    const nextMessages = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setSending(true);
    try {
      const { data } = await api.post("/assistant/ask", { message: text, history: nextMessages });
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
    } catch (err) {
      if (err.response?.status === 503) setUnavailable(true);
      setMessages((m) => [...m, { role: "assistant", content: "Sorry, I'm not able to reply right now." }]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {open && (
        <div className="mb-3 w-80 sm:w-96 h-[28rem] bg-white border border-brass/40 rounded-sm shadow-2xl flex flex-col overflow-hidden">
          <div className="bg-ink text-parchment px-4 py-3 flex items-center justify-between">
            <p className="font-ui text-sm">📖 AI Librarian</p>
            <button onClick={() => setOpen(false)} className="text-parchment/70 hover:text-parchment">✕</button>
          </div>

          {unavailable && (
            <p className="font-ui text-[11px] text-rust px-4 py-2 bg-rust/10 border-b border-rust/20">
              AI librarian isn't configured on this server yet (missing ANTHROPIC_API_KEY).
            </p>
          )}

          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`font-ui text-sm max-w-[85%] px-3 py-2 rounded-sm ${
                m.role === "user" ? "bg-burgundy text-white ml-auto" : "bg-parchment text-ink"
              }`}>
                {m.content}
              </div>
            ))}
            {sending && <div className="font-ui text-xs text-ink/40">Thinking…</div>}
            <div ref={bottomRef} />
          </div>

          <form onSubmit={send} className="flex gap-2 p-3 border-t border-brass/20">
            <input value={input} onChange={(e) => setInput(e.target.value)}
              placeholder="Ask for a recommendation…"
              className="flex-1 px-3 py-2 border border-brass/40 rounded-sm bg-parchment font-ui text-sm outline-none focus:border-brass" />
            <button disabled={sending} className="bg-burgundy text-white px-3 py-2 rounded-sm font-ui text-sm disabled:opacity-40">
              Send
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => setOpen((o) => !o)}
        className="w-14 h-14 rounded-full bg-burgundy text-white shadow-xl flex items-center justify-center text-2xl hover:bg-burgundy2 transition-colors"
        aria-label="Open AI librarian chat"
      >
        {open ? "✕" : "💬"}
      </button>
    </div>
  );
};

export default AIChatWidget;
