/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Values come from CSS custom properties (see index.css), stored as
        // "R G B" triplets so Tailwind's opacity modifiers (bg-ink/10 etc.)
        // keep working — the same class names automatically repaint when
        // the .dark class toggles on <html>.
        ink: "rgb(var(--color-ink) / <alpha-value>)",
        parchment: "rgb(var(--color-parchment) / <alpha-value>)",
        parchment2: "rgb(var(--color-parchment2) / <alpha-value>)",
        burgundy: "rgb(var(--color-burgundy) / <alpha-value>)",
        burgundy2: "rgb(var(--color-burgundy2) / <alpha-value>)",
        brass: "rgb(var(--color-brass) / <alpha-value>)",
        sage: "rgb(var(--color-sage) / <alpha-value>)",
        rust: "rgb(var(--color-rust) / <alpha-value>)",
        // The catalog cards throughout the app use bg-white/NN as a
        // translucent "paper" surface — redefine white the same var-driven
        // way so those cards flip to a dark surface instead of staying a
        // literal white box when .dark is active.
        white: "rgb(var(--color-surface) / <alpha-value>)",
      },
      fontFamily: {
        display: ["'Playfair Display'", "serif"],
        body: ["'Source Serif 4'", "serif"],
        ui: ["'Inter'", "sans-serif"],
      },
    },
  },
  plugins: [],
};
